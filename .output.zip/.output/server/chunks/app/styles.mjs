const interopDefault = r => r.default || r || [];
const styles = {
  "node_modules/nuxt/dist/app/entry.js": () => import('./_nuxt/entry-styles.f164dfe0.mjs').then(interopDefault),
  "pages/home/index.vue": () => import('./_nuxt/index-styles.28c99c87.mjs').then(interopDefault),
  "pages/jobs/[job].vue": () => import('./_nuxt/_job_-styles.b3f48157.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": () => import('./_nuxt/error-404-styles.cf00f4cc.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": () => import('./_nuxt/error-500-styles.a001b7ed.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
