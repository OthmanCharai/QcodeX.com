const client_manifest = {
  "_Footer.c5fde4c3.js": {
    "resourceType": "script",
    "module": true,
    "file": "Footer.c5fde4c3.js",
    "imports": [
      "_nuxt-link.00c35ba2.js",
      "_swiper-vue.2d18d3d9.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_nuxt-link.00c35ba2.js": {
    "resourceType": "script",
    "module": true,
    "file": "nuxt-link.00c35ba2.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.2d18d3d9.js"
    ]
  },
  "_swiper-vue.2d18d3d9.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "swiper-vue.693050bc.css"
    ],
    "file": "swiper-vue.2d18d3d9.js"
  },
  "swiper-vue.693050bc.css": {
    "file": "swiper-vue.693050bc.css",
    "resourceType": "style"
  },
  "assets/fonts/fa-brands-400.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "fa-brands-400.0b7f21ab.ttf",
    "src": "assets/fonts/fa-brands-400.ttf"
  },
  "assets/fonts/fa-light-300.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "fa-light-300.c3d1b364.ttf",
    "src": "assets/fonts/fa-light-300.ttf"
  },
  "assets/fonts/fa-regular-400.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "fa-regular-400.8e218c12.ttf",
    "src": "assets/fonts/fa-regular-400.ttf"
  },
  "assets/fonts/fa-solid-900.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "fa-solid-900.7e3132e8.ttf",
    "src": "assets/fonts/fa-solid-900.ttf"
  },
  "assets/fonts/flaticon.eot": {
    "resourceType": "font",
    "mimeType": "font/eot",
    "file": "flaticon.d001cf0f.eot",
    "src": "assets/fonts/flaticon.eot"
  },
  "assets/fonts/flaticon.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "flaticon.56169f3e.svg",
    "src": "assets/fonts/flaticon.svg"
  },
  "assets/fonts/flaticon.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "flaticon.8f46fae0.ttf",
    "src": "assets/fonts/flaticon.ttf"
  },
  "assets/fonts/flaticon.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "flaticon.fa43435c.woff",
    "src": "assets/fonts/flaticon.woff"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.23f2309d.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-404.b98f5465.js",
    "imports": [
      "_nuxt-link.00c35ba2.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.2d18d3d9.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.23f2309d.css": {
    "file": "error-404.23f2309d.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.aa16ed4d.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-500.a8a49300.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.2d18d3d9.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.aa16ed4d.css": {
    "file": "error-500.aa16ed4d.css",
    "resourceType": "style"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.7fa9df0e.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "entry.7fa9df0e.css"
    ],
    "dynamicImports": [
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "entry.bdf913a0.js",
    "imports": [
      "_swiper-vue.2d18d3d9.js"
    ],
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "entry.7fa9df0e.css": {
    "file": "entry.7fa9df0e.css",
    "resourceType": "style"
  },
  "pages/contact/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.32b32f81.js",
    "imports": [
      "_Footer.c5fde4c3.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.2d18d3d9.js",
      "_nuxt-link.00c35ba2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/contact/index.vue"
  },
  "pages/home/index.css": {
    "resourceType": "style",
    "file": "index.ac732715.css",
    "src": "pages/home/index.css"
  },
  "pages/home/index.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "index.386dda91.js",
    "imports": [
      "_Footer.c5fde4c3.js",
      "_nuxt-link.00c35ba2.js",
      "_swiper-vue.2d18d3d9.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/home/index.vue"
  },
  "index.ac732715.css": {
    "file": "index.ac732715.css",
    "resourceType": "style"
  },
  "pages/jobs/[job].css": {
    "resourceType": "style",
    "file": "_job_.46839562.css",
    "src": "pages/jobs/[job].css"
  },
  "pages/jobs/[job].vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "pattern-45.03345372.png"
    ],
    "css": [],
    "file": "_job_.822410af.js",
    "imports": [
      "_Footer.c5fde4c3.js",
      "_nuxt-link.00c35ba2.js",
      "_swiper-vue.2d18d3d9.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/jobs/[job].vue"
  },
  "_job_.46839562.css": {
    "file": "_job_.46839562.css",
    "resourceType": "style"
  },
  "pattern-45.03345372.png": {
    "file": "pattern-45.03345372.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "public/images/background/pattern-45.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "pattern-45.03345372.png",
    "src": "public/images/background/pattern-45.png"
  },
  "swiper-vue.css": {
    "resourceType": "style",
    "file": "swiper-vue.693050bc.css",
    "src": "swiper-vue.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
