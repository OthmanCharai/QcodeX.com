const Slider_vue_vue_type_style_index_0_lang = ".a{color:red}";

const indexStyles_28c99c87 = [Slider_vue_vue_type_style_index_0_lang];

export { indexStyles_28c99c87 as default };
//# sourceMappingURL=index-styles.28c99c87.mjs.map
