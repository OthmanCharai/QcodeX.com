import { _ as __nuxt_component_0$1 } from './nuxt-link-563b35af.mjs';
import { useSSRContext, mergeProps, withCtx, createVNode, createTextVNode, toDisplayString } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderAttr, ssrRenderComponent, ssrRenderList } from 'vue/server-renderer';
import { _ as _export_sfc } from '../server.mjs';

const _imports_0$1 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAfEAAADLBAMAAACMircxAAAAG1BMVEXu7u4AAADQ0NAdHR1ZWVmUlJSysrI7Ozt3d3csCJl7AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAHF0lEQVR4nO2az3PUNhTHN1r/2GPFpkmO69lSeqxhCj3GZVKudZuZ9hjTMnDE0APHNUzpv13L+vUkWQ6ZxIaZfj+nXdmW9dV7ek8/vFoBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA8D/hu7d8+273CTc2nPMr8n/N+dZ/7v6zcvvko1P06i1/dLFzS8rtu6vVZ2DPuW3JSy44/UX9LbnDa/LYpv//PflfcX7i1fy7fOrYVr/6EJTIm7aHO1ByUyqiPFEST1XJhPJV2yuw/7L+8sGt+E/92JkpeqBKfghKtld3peeTSblVzozSr2XBlPLCcffec07dijf2uXNVlJn6DrrE3HO2WpqCKN/bxkp/n1KeOu7ee8A9t+LaPqf7pDAlqmeHaOF1xmKURDkReuIXBModd9+YztJk9MHzoP5d5I3LkZBmDL9/fM7+4jpOe8qvnEf3pKRxBr1gLSq52LFXpVElumf7fne/NZ0o3rj9uGMizG3nERilIcob7YYPrJnojZ5VhLs/VL9LN9D3dNqBU+PuhSpKjbvrkiEauj4zNzKm7eSf1qTkMEWJGw/ew5UxdBI4hOgLVYXxjUoLbrSFzXtY2HUzk5NBx7iJUnkQqcMS6dDSUHUQmzNrxEx5EDNhLNV9YQNbHUTImelfWGrlJEoxTqc3gs56tiHT7s6C6CcqMwO3kvZMbVEl+yKzJeuFQ1zf5DMzk8lJYzvPt7PQneVdx/rJnXspIV7QO/dX8i5dVMiSjS1JbKZbhL6nXxvlR+TlhWfEfRC71eODl3Rhs6kN19KTj6xD5+rqi38fq5KllQvVRnlBhtpaGoXeOBKAVGTQA9m59OKZGR1KeWPr2ARxIV/W2zPR0UY5aZloyD33xhFnH4x9OjjEZDJWyjsyjQ3i5ZHX1TOzF22hyo2H567zrUedXaaGg8iGk/ZSqiqSsvvn3Hu6IEbOSisC06jyxHXHLpJzhLufbPg1k25VcUv8pvRyRxpxqpnYDLaK2ZwoZ1FtfVbc1iOp3qGVT1O1rSuUVRGnmolmaBGNcGacu+6dRAeyWtAHqZ6igwT18MpR/qINJwSzUg62olnNuHTh2LGIphy1or+aeo2a/jHafXTMy5XqkiZPpFKjfE083PXgKm6R5vpWdzIAOso7X/l2yfVKLd9ulFOfLqlyNmHVwd0n1xqp8mQnk9E5Yj10XuwFM8CUrYxyMiHZcNrMZCqElcEU36NRU9uo8m7w9tOrG7X+NuTKVhXdIFF+WzvKi6l83V6zss70YtxRXhPllYySy23EdXbVvDPN4W/Ej2849wwU9edhn3FqfdnojBhV/uyfP57ykQnwXGS6l61ysQDhF7thN4o2s5ywauPeGpCaABhVLnjJl1uxrHW8tsrJpuEZaWY6NS2XWe0Qvd4ZY0bHuS4IjmhmwggmJw21UX5OUlU+MQbVTCYaBhKb86aVXzsFvjNS411EeaqFHzOivJgYyH1fHbdxn2CtHb/MU+4NoHapjbjCtIieLukDoQMjdp5YRolM/7CIR6c9idnROZwk3NudiZbuie1MscytP8mVu2IiwA2bMmnU3YfAMboyrYK50XqhEMe4x0FduCz5k/eD35+QW2PVyCVWG4tOoh8fm38lqacNpj/JQlP3qHLbDj22N/Gspc4ahE+PjYfhBGVn/lK1ZdCbmy9EeW43h/K4G6rjVDNN8xDh7Y396+7J+EFxooPvlOuUk73XidDeqvgl5p+74GrOXTPWzuGxL/NLsTlpZR0N7Rvt5etRd2+5GxrJno/ae2WvntJdoC9CeWtjbzDpMDTa1BkfmezkfsgP99sLsuF6tPCG+8pdpep3k2Mff8vMIvZj1AMdD2+q/IgfnrFQtfXyJ+hGOZm3UdeLJrXczmDET28GRs+YTQmZQ7xeuedZ5dKHqd76XP0iu8xZdG7a2SuMB6O0CJI8Mz2l95jJZD0JR9zsWOVmu21jrSlaOR55MjqOa+5P9NrQeyvt7vr8nHG6epje2pkBq7xRn4Mx2owktlJbUyvlvm9nQVfI9H++ot9MVLqOB2Mxcm6s8iEBP199W9FmRI/6KmeTsvQydO6mjqEK9VXM8J2MHNN7WcIueRgo5scqp6nuXF9eRyYyXgQzm06KYkS5/dyObnpqltqYsIzuTFj7xQ45C9edhT1pD3UjysnXbzqZ1f4tS0KU288W7YysiLhh6UW+0s0B7Zhya2LdZ2Yv5DOY3FmfaxOQYBNRnvgD03N34tjEoHrnw373aj67PL8DKTeEKmdy75t+i9yMT9tr7mWhjeuwfFT5yLfOv8kbfr6tjNvCLh/xJxczvuBy9Pv2v3+d8ZUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAfD7+A8b4M077VVt4AAAAAElFTkSuQmCC";
const _imports_1$1 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAAA9BAMAAAC99I38AAAAG1BMVEXu7u4AAADQ0NAdHR13d3c7OzuUlJSysrJZWVmk6HwjAAAACXBIWXMAAA7EAAAOxAGVKw4bAAABUUlEQVRYhe2UwU6EMBCGx1Yox60Fl2N1s4lH2FXxCPEFlvgCEuO9aNbz4pM70xL0WLit6Z9QJk3nY+ZvKUBQUFBQUNB/1qYGaKTMAZ5VTRN8jcNgw3f5jSO792W1mNUSK7FAAKHwySi6lFJpgCj1RG0lsvYU9ZUoDbia+JWdeWT4JdZ6smJJq209g4H+RAGChtdx5qKALvNk8aqrQdjFWBwvKBCZaxEe7Lj/8mQJQFacDk8aMD+yrUHzsqMXy7fkvYl9/SIWui7X1GjiWFwaV5/zfhYrSvVR/WElUluWrFh7mMkilbe/rF4eHEsDXy1gDR/k14pCVn7abKYcfT7LTPsY5cI1uYR1U2AtejpfXQGDhbYGNnN7jHJ9zKdzz8gmm96h96eZLIZnYgfR+D/ya7KdqMmCMwF3JV0F4z3R0CY2tsk3RfeEPysoKCgoKOj89AOtPDKksaVynAAAAABJRU5ErkJggg==";
const services = [
  {
    name: "SALES FORCE",
    title: "Data for sales forces: selling more, and selling better",
    content: "Maximizing sales force effectiveness: achieving higher sales volumes and improved sales techniques for greater success.",
    image: "background-image: url(./../public/images/background/1.jpg)",
    about: {
      content: "Data for sales forces: selling more, and selling better.",
      mission: "Good inter-personal skills, a taste for challenge, and in-depth knowledge of the customer: the key skills every successful salesperson should have never change. However, the advent of Big Data is transforming the methods used by the profession. This avalanche of data is an opportunity to learn even more about targets and markets. More flexible and more accurate, digital tools are set to become invaluable companions for sales forces.",
      vision: "Data is revolutionizing sales forces, enabling them to anticipate purchases, model needs, build loyalty, and get a big-picture view. Business Intelligence solutions do not just make life easier; they also make it more agile. Used in conjunction with a CRM system, they greatly increase your sales firepower. The latest-generation dashboards enhance teamwork thanks to their more attractive style and greater ease of use. By paving the way to better-targeted and higher-quality actions, BI solutions set you free to focus on the most strategic aspect of your job: selling.",
      value: "Our mission is to add value by empowering sales forces to reach their full potential. Through comprehensive support and innovative solutions, we aim to optimize sales performance and foster lasting customer relationships. By providing cutting-edge training, data-driven strategies, and personalized coaching, we enable sales teams to excel in today's competitive market, driving consistent growth and delivering unparalleled value to our clients. With a customer-centric approach, we continuously strive to enhance sales techniques and maximize results, ensuring that our services truly add value to their businesses."
    },
    references: [
      {
        image: "././../../public/images/resource/process-1.png",
        year: "2010",
        title: "Started business",
        description: "A People Ops leader who is committed to the growth and development of leaders",
        color: "n"
      },
      {
        image: "././../../public/images/resource/process-1.png",
        year: "2010",
        title: "Started business",
        description: "A People Ops leader who is committed to the growth and development of leaders",
        color: "style-two"
      },
      {
        image: "././../../public/images/resource/process-1.png",
        year: "2010",
        title: "Started business",
        description: "A People Ops leader who is committed to the growth and development of leaders",
        color: "style-three"
      },
      {
        image: "././../../public/images/resource/process-1.png",
        year: "2010",
        title: "Started business",
        description: "A People Ops leader who is committed to the growth and development of leaders",
        color: "style-for"
      }
    ],
    teams: [
      {
        image: "./../../public/images/resource/team-1.jpg",
        name: "Othman Charai",
        role: "Software eng",
        description: "Our goal is to propel your business forward with world-class IT cybersecurity and technology solutions."
      },
      {
        image: "./../../public/images/resource/team-1.jpg",
        name: "Othman Charai",
        role: "Software eng",
        description: "Our goal is to propel your business forward with world-class IT cybersecurity and technology solutions."
      },
      {
        image: "./../../public/images/resource/team-1.jpg",
        name: "Othman Charai",
        role: "Software eng",
        description: "Our goal is to propel your business forward with world-class IT cybersecurity and technology solutions."
      },
      {
        image: "./../../public/images/resource/team-1.jpg",
        name: "Othman Charai",
        role: "Software eng",
        description: "Our goal is to propel your business forward with world-class IT cybersecurity and technology solutions."
      }
    ]
  },
  {
    name: "DATA TRAINING",
    title: "Empowering Your Team with Data Expertise",
    content: "Equipping your workforce with the skills and knowledge needed to harness the power of data-driven decision-making.",
    image: "background-image: url(./../public/images/background/2.jpg)",
    about: {
      content: "Data Training: Empowering Your Team with Data Expertise.",
      mission: "In the rapidly evolving digital landscape, data literacy is essential for any successful organization. Our mission is to empower your team with the skills and knowledge needed to harness the power of data. Through comprehensive training programs and hands-on workshops, we aim to equip your workforce with data analysis, visualization, and interpretation capabilities. By fostering a data-driven culture, your team can make informed decisions, drive efficiency, and identify new opportunities for growth.",
      vision: "We envision a future where every member of your organization is fluent in data, leveraging insights to drive innovation and excellence. Our data training services provide a solid foundation for your team to navigate the complexities of modern data ecosystems confidently. As data becomes increasingly integral to decision-making across industries, we strive to make data expertise accessible and practical for all levels of your organization.",
      value: "At the core of our data training services is the belief that knowledge empowers and unlocks untapped potential. By investing in data training, you invest in your team's growth and effectiveness. Our tailored programs cater to the specific needs of your organization, ensuring that your team gains practical skills that yield immediate value. With data proficiency, your team can adapt to dynamic challenges, drive innovation, and continuously optimize processes, leading to a more agile and successful organization."
    },
    references: [
      {
        image: "././../../public/images/resource/process-2.png",
        year: "2015",
        title: "Data Training Program Launched",
        description: "Introduced data training initiatives to boost team data literacy.",
        color: "n"
      },
      {
        image: "././../../public/images/resource/process-2.png",
        year: "2015",
        title: "Data Training Program Launched",
        description: "Introduced data training initiatives to boost team data literacy.",
        color: "style-two"
      },
      {
        image: "././../../public/images/resource/process-2.png",
        year: "2015",
        title: "Data Training Program Launched",
        description: "Introduced data training initiatives to boost team data literacy.",
        color: "style-three"
      },
      {
        image: "././../../public/images/resource/process-2.png",
        year: "2015",
        title: "Data Training Program Launched",
        description: "Introduced data training initiatives to boost team data literacy.",
        color: "style-for"
      }
    ],
    teams: [
      {
        image: "./../../public/images/resource/team-2.jpg",
        name: "Jennifer Smith",
        role: "Data Training Specialist",
        description: "Passionate about empowering individuals with data expertise, Jennifer leads our data training initiatives, ensuring your team gains the skills to thrive in a data-driven world."
      },
      {
        image: "./../../public/images/resource/team-2.jpg",
        name: "Jennifer Smith",
        role: "Data Training Specialist",
        description: "Passionate about empowering individuals with data expertise, Jennifer leads our data training initiatives, ensuring your team gains the skills to thrive in a data-driven world."
      },
      {
        image: "./../../public/images/resource/team-2.jpg",
        name: "Jennifer Smith",
        role: "Data Training Specialist",
        description: "Passionate about empowering individuals with data expertise, Jennifer leads our data training initiatives, ensuring your team gains the skills to thrive in a data-driven world."
      },
      {
        image: "./../../public/images/resource/team-2.jpg",
        name: "Jennifer Smith",
        role: "Data Training Specialist",
        description: "Passionate about empowering individuals with data expertise, Jennifer leads our data training initiatives, ensuring your team gains the skills to thrive in a data-driven world."
      }
    ]
  },
  {
    name: "VBA EXCEL",
    title: "Automating Efficiency with VBA Excel",
    content: "Unlocking the full potential of Microsoft Excel through custom VBA solutions for increased productivity.",
    image: "background-image: url(./../public/images/background/3.jpg)",
    about: {
      content: "VBA Excel: Automating Efficiency with VBA Excel.",
      mission: "Microsoft Excel is a powerful tool for data analysis and reporting, but its true potential lies in custom automation with Visual Basic for Applications (VBA). Our mission is to streamline your workflows and boost productivity by developing tailored VBA solutions. From automating repetitive tasks to creating interactive dashboards, our VBA Excel services empower you to harness the full capabilities of Excel and save time, effort, and resources.",
      vision: "We envision a future where Excel users transform into Excel power users through VBA automation. By eliminating manual processes and enhancing Excel's functionality, our VBA solutions enable you to focus on strategic decision-making and analysis. Our team of experts is dedicated to providing efficient, reliable, and scalable VBA solutions that cater to your specific needs, enhancing your Excel experience like never before.",
      value: "Our VBA Excel services add tangible value to your operations by increasing efficiency and accuracy. We believe that automation should not be complicated, and our VBA solutions are designed with user-friendliness in mind. By collaborating with us, you gain access to a range of customized tools that can handle complex tasks, generate insightful reports, and turn raw data into actionable insights. Whether you are an Excel novice or an experienced user, our VBA solutions will elevate your Excel game and elevate your team's productivity."
    },
    references: [
      {
        image: "././../../public/images/resource/process-3.png",
        year: "2018",
        title: "Launched VBA Excel Services",
        description: "Introduced VBA Excel services to transform Excel workflows.",
        color: "n"
      },
      {
        image: "././../../public/images/resource/process-3.png",
        year: "2018",
        title: "Launched VBA Excel Services",
        description: "Introduced VBA Excel services to transform Excel workflows.",
        color: "style-two"
      },
      {
        image: "././../../public/images/resource/process-3.png",
        year: "2018",
        title: "Launched VBA Excel Services",
        description: "Introduced VBA Excel services to transform Excel workflows.",
        color: "style-three"
      },
      {
        image: "././../../public/images/resource/process-3.png",
        year: "2018",
        title: "Launched VBA Excel Services",
        description: "Introduced VBA Excel services to transform Excel workflows.",
        color: "style-for"
      }
    ],
    teams: [
      {
        image: "./../../public/images/resource/team-3.jpg",
        name: "John Doe",
        role: "VBA Excel Specialist",
        description: "As a seasoned VBA expert, John leads our VBA Excel team in developing bespoke solutions that elevate Excel functionality and drive operational efficiency."
      },
      {
        image: "./../../public/images/resource/team-3.jpg",
        name: "John Doe",
        role: "VBA Excel Specialist",
        description: "As a seasoned VBA expert, John leads our VBA Excel team in developing bespoke solutions that elevate Excel functionality and drive operational efficiency."
      },
      {
        image: "./../../public/images/resource/team-3.jpg",
        name: "John Doe",
        role: "VBA Excel Specialist",
        description: "As a seasoned VBA expert, John leads our VBA Excel team in developing bespoke solutions that elevate Excel functionality and drive operational efficiency."
      },
      {
        image: "./../../public/images/resource/team-3.jpg",
        name: "John Doe",
        role: "VBA Excel Specialist",
        description: "As a seasoned VBA expert, John leads our VBA Excel team in developing bespoke solutions that elevate Excel functionality and drive operational efficiency."
      }
    ]
  }
];
const jsonData = {
  services
};
const _sfc_main$1 = {
  __name: "Header",
  __ssrInlineRender: true,
  setup(__props) {
    const contact = {
      phone: "(678) 345-3456",
      email: "envato@mail.com",
      address: "380 Albert St, Melbourne, Australia",
      linkedin: "https://www.linkedin.com/",
      facebook: "https://www.linkedin.com/",
      twitter: "https://www.linkedin.com/",
      instagram: "https://www.linkedin.com/"
    };
    const route = {
      home: {
        url: "/home",
        name: "Home"
      }
    };
    const services2 = jsonData.services;
    const servicesHeader = [];
    services2.forEach((element) => {
      servicesHeader.push(element.name);
    });
    const formatService = (service) => {
      return "jobs/" + service;
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<header${ssrRenderAttrs(mergeProps({ class: "main-header header-style-two" }, _attrs))}><div class="header-top_two"><div class="auto-container"><div class="d-flex justify-content-center align-items-center flex-wrap"><ul class="info-list"><li><a href="#"><span class="icon fa-solid fa-phone fa-fw"></span>${ssrInterpolate(contact.phone)}</a></li><li><a href="#"><span class="icon fa-solid fa-envelope fa-fw"></span>${ssrInterpolate(contact.email)}</a></li><li><a href="#"><span class="icon fa-solid fa-map fa-fw"></span></a></li></ul><ul class="header-social_box"><li><a${ssrRenderAttr("href", contact.facebook)} class="fa-brands fa-facebook-f fa-fw"></a></li><li><a${ssrRenderAttr("href", contact.twitter)} class="fa-brands fa-twitter fa-fw"></a></li><li><a${ssrRenderAttr("href", contact.linkedin)} class="fa-brands fa-linkedin fa-fw"></a></li><li><a${ssrRenderAttr("href", contact.instagram)} class="fa-solid fa-instagram fa-fw"></a></li></ul></div></div></div><div class="header-upper"><div class="auto-container"><div class="inner-container d-flex"><div class="logo">`);
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: route.home.url
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_0$1)} alt="" title=""${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_0$1,
                alt: "",
                title: ""
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="upper-right"><div class="nav-outer d-flex justify-content-between align-items-center flex-wrap"><nav class="main-menu show navbar-expand-md"><div class="navbar-header"><button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button></div><div class="navbar-collapse collapse clearfix" id="navbarSupportedContent"><ul class="navigation clearfix"><li>`);
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: route.home.url
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(route.home.name)}`);
          } else {
            return [
              createTextVNode(toDisplayString(route.home.name), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="dropdown"><a href="#">Services</a><ul><!--[-->`);
      ssrRenderList(servicesHeader, (service) => {
        _push(`<li>`);
        _push(ssrRenderComponent(_component_nuxt_link, {
          to: formatService(service)
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(service)}`);
            } else {
              return [
                createTextVNode(toDisplayString(service), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</li>`);
      });
      _push(`<!--]--></ul></li><li>`);
      _push(ssrRenderComponent(_component_nuxt_link, { to: "/contact" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Contact`);
          } else {
            return [
              createTextVNode("Contact")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li></ul></div></nav><div class="outer-box d-flex align-items-center"><div class="search-box"><form method="post" action="contact.html"><div class="form-group"><input type="search" name="search-field" value="" placeholder="Search..." required><button type="submit"><span class="icon fa fa-search"></span></button></div></form></div><div class="language dropdown"><button class="btn dropdown-toggle" type="button" id="dropdownMenu1" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa-solid fa-globe fa-fw"></i>English \xA0<span class="fa fa-angle-down"></span></button><ul class="dropdown-menu" aria-labelledby="dropdownMenu1"><li><a href="#">English Branch</a></li><li><a href="#">German Branch</a></li><li><a href="#">UAE Branch</a></li><li><a href="#">Qatar Branch</a></li></ul></div><div class="button-box"><a class="btn-style-three theme-btn btn-item" href="#"><div class="btn-wrap">`);
      _push(ssrRenderComponent(_component_nuxt_link, { to: "/contact" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="text-one"${_scopeId}>Get a quote now <i class="fa-solid fa-arrow-right fa-fw"${_scopeId}></i></span><span class="text-two"${_scopeId}>Get a quote now <i class="fa-solid fa-arrow-right fa-fw"${_scopeId}></i></span>`);
          } else {
            return [
              createVNode("span", { class: "text-one" }, [
                createTextVNode("Get a quote now "),
                createVNode("i", { class: "fa-solid fa-arrow-right fa-fw" })
              ]),
              createVNode("span", { class: "text-two" }, [
                createTextVNode("Get a quote now "),
                createVNode("i", { class: "fa-solid fa-arrow-right fa-fw" })
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></a></div><div class="mobile-nav-toggler"><span class="icon fa-solid fa-bars fa-fw"></span></div></div></div></div></div></div></div><div class="sticky-header"><div class="auto-container"><div class="d-flex justify-content-between align-items-center"><div class="logo"><a href="index.html" title=""><img${ssrRenderAttr("src", _imports_0$1)} alt="" title=""></a></div><div class="right-box d-flex align-items-center flex-wrap"><nav class="main-menu"></nav><div class="outer-box d-flex align-items-center"><div class="search-box"><form method="post" action=""><div class="form-group"><input type="search" name="search-field" value="" placeholder="Search..." required><button type="submit"><span class="icon fa fa-search"></span></button></div></form></div><div class="language dropdown"><button class="btn dropdown-toggle" type="button" id="dropdownMenu2" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa-solid fa-globe fa-fw"></i>English \xA0<span class="fa fa-angle-down"></span></button><ul class="dropdown-menu" aria-labelledby="dropdownMenu2"><li><a href="#">English Branch</a></li><li><a href="#">German Branch</a></li><li><a href="#">UAE Branch</a></li><li><a href="#">Qatar Branch</a></li></ul></div><div class="button-box"><a class="btn-style-three theme-btn btn-item" href="#"><div class="btn-wrap"><span class="text-one">Get a quote now <i class="fa-solid fa-arrow-right fa-fw"></i></span><span class="text-two">Get a quote now <i class="fa-solid fa-arrow-right fa-fw"></i></span></div></a></div><div class="mobile-nav-toggler"><span class="icon fa-solid fa-bars fa-fw"></span></div></div></div></div></div></div><div class="mobile-menu"><div class="menu-backdrop"></div><div class="close-btn"><span class="icon flaticon-020-x-mark"></span></div><nav class="menu-box"><div class="nav-logo">`);
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: route.home.url
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_1$1)} alt="" title=""${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_1$1,
                alt: "",
                title: ""
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="search-box"><form method="post" action=""><div class="form-group"><input type="search" name="search-field" value="" placeholder="SEARCH HERE" required><button type="submit"><span class="icon flaticon-001-loupe"></span></button></div></form></div><div class="menu-outer"></div></nav></div></header>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Landing/Header.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$1;
const _imports_0 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKoAAAA8BAMAAAAEZzzvAAAAG1BMVEXu7u4AAADQ0NBZWVk7OzuUlJQdHR13d3eysrKnp9RnAAAACXBIWXMAAA7EAAAOxAGVKw4bAAABmUlEQVRYhe2UPW/CMBCGLyEOGXGggTFRq3QlHToTJsYiVcy4Cx2JVHUOS39378OIDB1iut47BOsSHp/vXh+ASqVSqVSqv1WtAZxFbSB+Lc4cazf4qB94/W13+Hx0pyBqe6NW1i5kJwI2a1rW+KaHmN+P15PlP0NWlOC2xnGyxpZgMECbfsbNEdJFeViOhxrnqfUKOQCXmRwAE19dN0tWsD9CZsdTu3knVDzvBLNJmUUlaDk+kQwbPILrR1O/eqHGeGYieoqxzwUv0px/iNicR1NLEGqCtAgJ07nEWye4aPZOHsA9/YcjJR9XuVCNp9ZWMqtO7AGi7sOpZKNodqMm9k2odpu1OVCn7qBSMsNcO/shVDRwurwzVzLVsK6ZPdzuA8buqyu3fuCBdG6kBBHGzCLUA57KNh34Fa9TwyZIJNdAv3pqRVeK79aRYgbbXnMJKJY+8N0qAqBC3W9o6baZzIFqSaXlpdtlLc+Bn4A54KnSict1ZvEk7HIfK3rcImxmCVA6cZ2vU2o5pIWPvUD4fFWpVCqVSvU//QKMXj9f1SqhoQAAAABJRU5ErkJggg==";
const _imports_1 = "data:image/jpeg;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAABLBAMAAADKYGfZAAAAG1BMVEXu7u4AAAB3d3fQ0NCUlJRZWVkdHR2ysrI7Ozsn1U2mAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAkklEQVRIie3OoQ7CMBAG4D9tV2YbkunBE1QVC2IJsgweYCCGrWGaZAIem6tvBf7/xF2T/rk7gIiI/qGc8/cOWBA8dm5r3VQODsgfKn6kmmgr4/Sk56f0by8lIMypGGuOZl2kn7yUG86H8tK8pfXQj7c8cmQtxl4wV5nWphHYRAyVaXvgIreNsAmqR9OVbyMioqofn1kR0xY+HF4AAAAASUVORK5CYII=";
const _imports_2 = "data:image/jpeg;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAABLBAMAAADKYGfZAAAAG1BMVEXu7u4AAAB3d3fQ0NCUlJRZWVkdHR2ysrI7Ozsn1U2mAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAkklEQVRIie3OoQ7CMBAG4D9tV2YbkunBE1QVC2IJsgweYCCGrWGaZAIem6tvBf7/xF2T/rk7gIiI/qGc8/cOWBA8dm5r3VQODsgfKn6kmmgr4/Sk56f0by8lIMypGGuOZl2kn7yUG86H8tK8pfXQj7c8cmQtxl4wV5nWphHYRAyVaXvgIreNsAmqR9OVbyMioqofn1kR0xY+HF4AAAAASUVORK5CYII=";
const _imports_3 = "data:image/jpeg;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAABLBAMAAADKYGfZAAAAG1BMVEXu7u4AAAB3d3fQ0NCUlJRZWVkdHR2ysrI7Ozsn1U2mAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAkklEQVRIie3OoQ7CMBAG4D9tV2YbkunBE1QVC2IJsgweYCCGrWGaZAIem6tvBf7/xF2T/rk7gIiI/qGc8/cOWBA8dm5r3VQODsgfKn6kmmgr4/Sk56f0by8lIMypGGuOZl2kn7yUG86H8tK8pfXQj7c8cmQtxl4wV5nWphHYRAyVaXvgIreNsAmqR9OVbyMioqofn1kR0xY+HF4AAAAASUVORK5CYII=";
const _imports_4 = "data:image/jpeg;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAABLBAMAAADKYGfZAAAAG1BMVEXu7u4AAAB3d3fQ0NCUlJRZWVkdHR2ysrI7Ozsn1U2mAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAkklEQVRIie3OoQ7CMBAG4D9tV2YbkunBE1QVC2IJsgweYCCGrWGaZAIem6tvBf7/xF2T/rk7gIiI/qGc8/cOWBA8dm5r3VQODsgfKn6kmmgr4/Sk56f0by8lIMypGGuOZl2kn7yUG86H8tK8pfXQj7c8cmQtxl4wV5nWphHYRAyVaXvgIreNsAmqR9OVbyMioqofn1kR0xY+HF4AAAAASUVORK5CYII=";
const _imports_5 = "data:image/jpeg;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAABLBAMAAADKYGfZAAAAG1BMVEXu7u4AAAB3d3fQ0NCUlJRZWVkdHR2ysrI7Ozsn1U2mAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAkklEQVRIie3OoQ7CMBAG4D9tV2YbkunBE1QVC2IJsgweYCCGrWGaZAIem6tvBf7/xF2T/rk7gIiI/qGc8/cOWBA8dm5r3VQODsgfKn6kmmgr4/Sk56f0by8lIMypGGuOZl2kn7yUG86H8tK8pfXQj7c8cmQtxl4wV5nWphHYRAyVaXvgIreNsAmqR9OVbyMioqofn1kR0xY+HF4AAAAASUVORK5CYII=";
const _imports_6 = "data:image/jpeg;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAABLBAMAAADKYGfZAAAAG1BMVEXu7u4AAAB3d3fQ0NCUlJRZWVkdHR2ysrI7Ozsn1U2mAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAkklEQVRIie3OoQ7CMBAG4D9tV2YbkunBE1QVC2IJsgweYCCGrWGaZAIem6tvBf7/xF2T/rk7gIiI/qGc8/cOWBA8dm5r3VQODsgfKn6kmmgr4/Sk56f0by8lIMypGGuOZl2kn7yUG86H8tK8pfXQj7c8cmQtxl4wV5nWphHYRAyVaXvgIreNsAmqR9OVbyMioqofn1kR0xY+HF4AAAAASUVORK5CYII=";
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<footer${ssrRenderAttrs(mergeProps({
    class: "main-footer",
    style: { "background-image": "url(~/assets/images/background/pattern-11.png)" }
  }, _attrs))}><div class="auto-container"><div class="widgets-section"><div class="row clearfix"><div class="big-column col-lg-6 col-md-12 col-sm-12"><div class="row clearfix"><div class="footer-column col-lg-6 col-md-6 col-sm-12"><div class="footer-widget logo-widget"><div class="logo"><a href="index.html"><img${ssrRenderAttr("src", _imports_0)} alt=""></a></div><div class="text"> We work with a passion of taking challenges and creating new ones in advertising sector. </div><a href="#" class="theme-btn about-btn">About us</a></div></div><div class="footer-column col-lg-6 col-md-6 col-sm-12"><div class="footer-widget newsletter-widget"><h4>Newsletter</h4><div class="text"> Subscribe our newsletter to get our latest update &amp; news </div><div class="email-box"><form method="post" action="/contact"><div class="form-group"><input type="email" name="search-field" value="" placeholder="Your mail address" required><button type="submit"><span class="icon fa-solid fa-paper-plane fa-fw"></span></button></div></form></div><ul class="social-box"><li><a href="https://www.twitter.com/" class="fa-brands fa-facebook-f fa-fw"></a></li><li><a href="https://www.facebook.com/" class="fa-brands fa-twitter fa-fw"></a></li><li><a href="https://dribbble.com/" class="fa-solid fa-dribbble fa-fw"></a></li><li><a href="https://behance.com/" class="fa-solid fa-behance fa-fw"></a></li></ul></div></div></div></div><div class="big-column col-lg-6 col-md-12 col-sm-12"><div class="row clearfix"><div class="footer-column col-lg-6 col-md-6 col-sm-12"><div class="footer-widget contact-widget"><h4>Official info:</h4><ul class="contact-list"><li><span class="icon fa fa-phone"></span> 30 Commercial Road <br> Fratton, Australia </li><li><span class="icon fa fa-envelope"></span> 1-888-452-1505 </li></ul><div class="timing"><strong>Open Hours: </strong> Mon - Sat: 8 am - 5 pm, <br> Sunday: CLOSED </div></div></div><div class="footer-column col-lg-6 col-md-6 col-sm-12"><div class="footer-widget instagram-widget"><h4>Gallery</h4><div class="widget-content"><div class="images-outer clearfix"><figure class="image-box"><a class="lightbox-image" href="images/gallery/project-1.jpg"><img${ssrRenderAttr("src", _imports_1)} alt=""></a></figure><figure class="image-box"><a class="lightbox-image" href="./../../public/images/gallery/project-2.jpg"><img${ssrRenderAttr("src", _imports_2)} alt=""></a></figure><figure class="image-box"><a class="lightbox-image" href="./../../public/images/gallery/project-3.jpg"><img${ssrRenderAttr("src", _imports_3)} alt=""></a></figure><figure class="image-box"><a class="lightbox-image" href="./../../public/images/gallery/project-4.jpg"><img${ssrRenderAttr("src", _imports_4)} alt=""></a></figure><figure class="image-box"><a class="lightbox-image" href="./../../public/images/gallery/project-5.jpg"><img${ssrRenderAttr("src", _imports_5)} alt=""></a></figure><figure class="image-box"><a class="lightbox-image" href="./../../public/images/gallery/project-6.jpg"><img${ssrRenderAttr("src", _imports_6)} alt=""></a></figure></div></div></div></div></div></div></div></div><div class="footer-bottom"><div class="copyright"> 2023 \xA9 All rights reserved by <a href="#">Themexriver</a></div></div></div></footer>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Landing/Footer.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_5 = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { __nuxt_component_0 as _, __nuxt_component_5 as a, jsonData as j };
//# sourceMappingURL=Footer-9b3e5ea3.mjs.map
