const Slider_vue_vue_type_style_index_0_lang = ".my-width{width:93%}";

const _job_Styles_b3f48157 = [Slider_vue_vue_type_style_index_0_lang];

export { _job_Styles_b3f48157 as default };
//# sourceMappingURL=_job_-styles.b3f48157.mjs.map
