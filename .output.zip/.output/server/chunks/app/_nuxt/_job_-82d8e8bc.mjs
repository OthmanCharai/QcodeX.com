import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { j as jsonData, _ as __nuxt_component_0, a as __nuxt_component_5 } from './Footer-9b3e5ea3.mjs';
import { _ as __nuxt_component_0$1 } from './nuxt-link-563b35af.mjs';
import { unref, useSSRContext, mergeProps, withCtx, createVNode, createTextVNode, ref, toDisplayString, openBlock, createBlock, Fragment, renderList } from 'vue';
import { ssrRenderComponent, ssrRenderAttrs, ssrRenderStyle, ssrInterpolate, ssrRenderList, ssrRenderAttr, ssrRenderClass } from 'vue/server-renderer';
import { Swiper, SwiperSlide } from 'swiper/vue';
import { Autoplay, EffectCreative } from 'swiper/modules';
import { a as useRoute } from '../server.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'devalue';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'http-graceful-shutdown';
import 'unctx';
import 'vue-router';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';

const _sfc_main$4 = {
  __name: "Slider",
  __ssrInlineRender: true,
  props: {
    name: String,
    title: String,
    image: String,
    content: String
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "slider-two" }, _attrs))}><div class="single-item-carousel owl-carousel owl-theme fixedWIdth active"><div class="slider-two_image-layer slider-two my-width" style="${ssrRenderStyle(__props.image)}"></div><div class="auto-container"><div class="slider-two-content"><div class="slider-two_inner"><div class="slider-two_title mt-2">${ssrInterpolate(__props.title)}</div><div class="slider-two_text mt-5">${__props.content}</div><div class="slider-two_button-box mt-5">`);
      _push(ssrRenderComponent(_component_nuxt_link, {
        class: "btn-style-two theme-btn btn-item mt-5",
        to: "/contact"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="btn-wrap"${_scopeId}><span class="text-one"${_scopeId}>Contact one of our experts <i class="fa-solid fa-arrow-right fa-fw"${_scopeId}></i></span><span class="text-two"${_scopeId}>Contact one of our experts <i class="fa-solid fa-arrow-right fa-fw"${_scopeId}></i></span></div>`);
          } else {
            return [
              createVNode("div", { class: "btn-wrap" }, [
                createVNode("span", { class: "text-one" }, [
                  createTextVNode("Contact one of our experts "),
                  createVNode("i", { class: "fa-solid fa-arrow-right fa-fw" })
                ]),
                createVNode("span", { class: "text-two" }, [
                  createTextVNode("Contact one of our experts "),
                  createVNode("i", { class: "fa-solid fa-arrow-right fa-fw" })
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></div></div></section>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Job/Slider.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$4;
const _imports_0$1 = "" + buildAssetsURL("pattern-45.03345372.png");
const _imports_1 = "data:image/jpeg;base64,iVBORw0KGgoAAAANSUhEUgAAAdIAAAE3BAMAAADsx900AAAAG1BMVEXu7u4AAACUlJR3d3fQ0NA7OztZWVkdHR2ysrLZP327AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAFpklEQVR4nO3azW8bRRjHcddeJ3tk2ibhaAtUrhi16tUuFHPsIkR7jJEqrl2VEo5Z6Mu/zc77MzO2KaJar9D3c4jsx9lkfjuzszObTCYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACT98/VzS9HC72lUpfi7Vapu+k3VA9u1O8Ps6Pm6r5826j1f2vqvzZV6uvw5rHSXk8OF7SzvrSIbxulrpPPq5056kV6VJckrdXgSTci6Qdl/XSwYFStUr+FdzOlrtbJ5yt31HV2kEy6HT5pE5NOXQtDy4uC08nh27/5PPn0zB91IY+aqyRpM3hS3SyfdOmb6HusKIiDFv5NK4e/tgtHPRPVJkna5x466TImrXQ3fDn5tvU9VhSCNja7T32RfKYHwuXb6q/0KB1NJG0GT6rD+KTnrqd0j93uLQRdjLdMR6U5ygz2MxmmapKkT9XgSeci6dIP0pWbTIpCMAvDt0rnYfvNr8yLnTjKTG0had0On3Qnkra+585do4pCFK66+b6RvfZHfeZqM5UktZPz+pOl+Aj9NRUmlP71vVC9u68gbPzwDT3o1SH6LEzKdZMkfaeGT9o3uPNJ57HNNmJREKZuKNTFJSzy+fNjVhKvQ9Lv9W1rNXDSRt2745Nu4gXXmA4rCtLONnxbnIN4fir/Wafn8Cc+aW2WIsthk/bT47OQtPjdRxuztcO3SW+averPl9fule9TnXQxlUnvHv/hn96yvx+EpLu834qCVJvhW64E02+x47jTy0mZtF88DZu00k0JSdt8HBaFxE4fXKwEpTOfrdOLfZH04vYfBswnN9chQ9Ki0cdS2AXCd21+o5U2fmR3P05k0ovFZOikZnj6pJVpyfRXdeW2o0UhpYfvyz7twZ9ehdvxD/pLSFqZ4qBJp2YJ5JPW+j4/M4sXO2iLQmaVrgYKX6Vrimn6vYMm3Zhz7pP2LXllV2luDVgUMmYhma0Eo/pxtpc5ZdLG9JVP2k+jrzq/3brdV8iYzcGB2dl8lg6FEyY9s+dcJH0RNpb39xVyywOdPXGrg6tbWTph0qW9FfqkffCbfs3WbyyVnWeKQm6u8j14YB9WvM5KJ0pauZuISOrGm16XXu8p5LrDE5Ldu6g/ROl0SecuYZJ0YT5amUYVhVx7+Dqd/fzNo2y+Ol1Sv9aTSd0UMjevikLGPhg7MHx7+gYl9nonSzr1s4lM6u4Klbkui0LGPk47sozaJovikyXd+DuHTLpwH+50M4pCSt9IdsfWSGaRFLv8ZEkbPx5lUtGMRVlI9evei7P9U5XXyecRp0paq5TZgIXpZbO3kDJb8bZ47CLN5eAeT9KpWKbe2VtI2Mcr+kZzuMEzOZGNJ2mdBrsuCwn7yGymimcO6S+Ja/zxJK3yYEUh0di5uzmw0TGqcSadiMvyzv6C4B9tb44N37EmbeJU25kYRUHwf23Tl2v6vLf64vk6/pLTJ41Cd63i3sy+LAqRvlXagE3+DL+L3T+TM/OIknbxWrS9WRQivY25Na+2KjsJm9jJ52O4y0Qhafzjixt1RSFahYlIXwbJJlXEW45h5RCFpHGl4BpbFIJa3Fx22VmYhRXiSFaDQZxWWz9ady5HUfDk2t3/kdWrwgpxm8zLY0q6dP+Z8NRfekXB24k+1v17P/vQHFWPZNcWxKR6vX75tnqv/HgsCs40Wdivsv34uT3qSZOun8aU1PzzgfXsQMHqks1a/jhJX56OPAOjSvo0tHB9oGC1SaP1hZnMVx/2np9RJXWP5cXQLApa9i9mutHJfrzyQ2Esz3sdmdS1Mf4bXFHQltmFWezHp/aoy3VSPHnSRPWgVW8eHit83I95dKPe7P27FQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwP/e30w3CdhRGlmOAAAAAElFTkSuQmCC";
const _imports_2 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADYAAABBCAYAAACaYlekAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNS1jMDIxIDc5LjE1NTc3MiwgMjAxNC8wMS8xMy0xOTo0NDowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTQgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjEwMEY5RDMyQTIwNDExRURCN0IxQkZGMjMwNUU0ODgxIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjEwMEY5RDMzQTIwNDExRURCN0IxQkZGMjMwNUU0ODgxIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6MTAwRjlEMzBBMjA0MTFFREI3QjFCRkYyMzA1RTQ4ODEiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6MTAwRjlEMzFBMjA0MTFFREI3QjFCRkYyMzA1RTQ4ODEiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5fQLfxAAAH0klEQVR42txaCWxWRRDe/+9By1FoQSmUq1S5STnkUMAgV4BSPAggIiqHKSjIEUWpqQYQ8EKJlQBKAl5BigasolGggCLBpohcWkBCiy1a6EUh0P5t/+dsmQfbZd/ue2//QnSSL/mP2Z393u6bnZldQm6NjAGcBuQDZpD/icwFGBze+i8T8gI+EJAysR0QVVfGPS7bjQbcDygGnAKcAfwFKAdEAgYAXgPcpeinBJAM2AEoAAQDWgFiAXGAaMDvgI9vxUx0tJiBKzjQasksyVAKuGzx3wO3gthbLgeug2/rmlQQ4MJtIEbR3MlAgx0SGwJo5rANfQf/BJThABsB2gI6ObQ/CbCqrmbsgI0newiwBDAK0EbSV0t8UIsAe230W1BXpJ5SGP4SMFKjf+pJ1ytsrAg0qSclxrIBwyRt66Prjgf0AHQAREj0+ylm8GVdMg1xlmTLLxU3Yl76A9YAMgGFgnYXAb8BNgBGWNhPltg9ghHNnU4I9QFsAhQplsV0QdvHAAddeLyTOFBeKGm/pB3dO7+28wqMtTmQcVw7urz2BMClHwb05frurSBn4lkZsXdtdPAM1yYBUBngPWsmZ2OkjTZbZcSeUzRew+lPrsMNmXcS8xT6b8iIDZI0/IfTHepkoCGT3jNCZ6c7JTeLs/mLRPdpGbEQjNhFDYczejT68NkdoKdBlBH2oVEDT0w3p+S6M3bbSfR68TkTK5WYgvByBFMLUzbjQ7AXYA6ZcyOGG5PidNv5ikmvcgBbBDpF6Hiksk/wNBKY/wc7euIhYUbY+5euz1jNrDVt63TW2K0lVvD/WVGWy0sbQTK4nfm+1FE6cB/s8fUa1o68hy9wOmtLMbMguKKOcf8356N/nhh9j1pzv21kPncGDHSUPiS+IliaswkJre+kmxbcO76Z+z8U8LisNJCNGTJPdid+TsHIXSzhEcTbtjfxNGsPiCXe9v2Jt/NQoao/9yDx/7GLGEU5gFxi5GQR49J5Gbk0wET83AVwnPu/ECelnCe2FpAk6LA941AyMeSq7UpnfEq8reKJJwr6DW/sLjKtqiBGIZAsySO+1ERwY1d5jWL0xgbmcUWCYHqPWUYwl+ICC1K0szxmujsIy1GtexJw4+5J1azZesQT3ZF474aV7hHWmKKY978KPSQv1LGtNonRLystzBXgFmC+oMKRVyyOJ/7s3dq5kXH+FCmfB5PiuyJLTk2xWrc05HuCElsnscWuh0aWWv4q4ls5hPjPZLonVXqO+JZBKlZxWZVKsavJSj7ymi+bjbqjoRqcb3k/4j97yDkpcBq+JT2JcaVEqWqzJlpBiU1VZL+mlNkZpG9ZH0fL0sg/eo2U3COawk5nU4neBErsV0kA2RydhrmmS5Wm/dWkev9G28T8J/bWLEObks98vsNC501AuukV11scFDRhNuxKLDfbizbsFvh7PmRX9QKW0c1gPVagQ7PpF/nIYyEgS6DMuvitalYhxBvX3/7hQWQr4mkSY0eVrQZ35xwJwXhxrFVIJQriEpnP25Qz0LIrPM9wR87DKjrhPR3z+WHB/ytkseJPgFzuNzYGoxXdDOkgu48SuvLKjdNI5bqJxDh3/OY2XYarSOVgVGEKX3Ohnv0LVYk7D0vQ7P41AWM1syx2wJrY6BuEygpI9Q9vk6o9a6/vT9VZaSRo0AwSPOL5mkijpk3cvdeiDcNyR1nEuPpuGIwTbrMuVD2dQ4J854Qg+RPmTqEpB1+FnKsEonqDhDWS5llBg2dBrnaZ5mg7gZhVRn5U8K7xOsWqc4B66NJFBh5k9CKwpifSO0Y83hzbSWRwaKnFwzTBOq9OEr0+MmKyAs1FTrcXqfujo4mczWMS3SQZMVWJ6zOXBVY3mMPZSlHoSw/sV9kw+JIgVQjkYWAF1itrhUg22m1TLcUKG50kCXKltACQysDE1mkVmGKKyiu2xlL3aUVHyRaJ3g4XhOj2MV7Q3xSiPgzcgEdUjuRRwDeSjmm020DQjh4kLAZ8hw/oKtPGh0FABgasVjcCXpfY3Y2rJpxoimyNU9c+SdGe1ip6IOFohe5ojFmt7M0lAZZExbLYZ4OgTGgslq6wsZDUkdg5BM/GitcUgSPg6xfjsd5i57Awz8lAnV45oqcxPzpscwa3g0v4vQEuzXbE2XWImYr6jGPpS2pf5vqb3J4LLOYYwgBdA0GMBsCPMN+X3QZSbILbEdOnUB1S9bHjT5jf2gkM04th5/AhFLsYOF2mJzH1Fx37sim5ef8xXofYVOyEr1D1w2x7Kh5SxDDvC03Z6b2Pn20QOoFZQyST+LbA/mlYNR+9Jb+CtC9zfs8MYrmL9rLD+jQiPsaSyWTO+7oSD7n5/uB0iX5ji813uoCU6FgzWlErTBD0E+OGWILFk87CEtc0XI709udhXK40XNovSProO5KJ2XCioAqWjm1p8kqLIvT86wXGxi6LsSxyQ+xzDS+W78DOPg07locFsjU+TOPdzHCgq3N79B7pYYnFpqyz7/R1YCtS05aje/yrNQyVuHjymRr2djoxlKthKNUFsZka9srxjEEpAzWXxgAXxNpo2kyyY+QdzUJMiEtHcErD7hY7Bg5rGNik4eGSNezSGwRBss67aC6JBA1iXTVtj5N1nqrZeYRmilSmYTtddtoSx2S6TmUHsXlOrQia57tsW+sO2L8CDADspMPX+8tdPAAAAABJRU5ErkJggg==";
const _sfc_main$3 = {
  __name: "About",
  __ssrInlineRender: true,
  props: {
    about: Object,
    name: String
  },
  setup(__props) {
    const props = __props;
    const activeTab = ref("prod-mission");
    const tabs = [
      {
        id: "prod-mission",
        title: "Our Mission",
        content: props.about.mission
      },
      {
        id: "prod-vision",
        title: "Our Vision",
        content: props.about.vision
      },
      {
        id: "prod-value",
        title: "Our Value",
        content: props.about.value
      }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "about-one" }, _attrs))}><div class="auto-container"><div class="row clearfix"><div class="about-one_content col-lg-6 col-md-12 col-sm-12"><div class="about-one_content-inner"><div class="sec-title"><div class="sec-title_title">About us</div><h2 class="sec-title_heading"> The Best <br><span>${ssrInterpolate(__props.name)}</span> Service Company </h2><div class="sec-title_text">${ssrInterpolate(__props.about.content)}</div></div><div class="about-info-tabs"><div class="about-tabs tabs-box"><ul class="tab-btns tab-buttons clearfix"><!--[-->`);
      ssrRenderList(tabs, (tab) => {
        _push(`<li${ssrRenderAttr("data-tab", tab.id)} act class="${ssrRenderClass([{ "active-btn": unref(activeTab) === tab.id }, "tab-btn"])}">${ssrInterpolate(tab.title)}</li>`);
      });
      _push(`<!--]--></ul><div class="tabs-content"><!--[-->`);
      ssrRenderList(tabs, (tab) => {
        _push(`<div class="${ssrRenderClass({
          "tab active-tab": unref(activeTab) === tab.id,
          tab: unref(activeTab) !== tab.id
        })}"${ssrRenderAttr("id", tab.id)}><div class="content"><div class="text">${ssrInterpolate(tab.content)}</div></div></div>`);
      });
      _push(`<!--]--></div></div></div><a class="about-one_detail lightbox-video" href="https://www.youtube.com/watch?v=kxPCFljwJws"> Check details about our company <span class="play-icon"><span class="fa-solid fa-play fa-fw"></span><i class="ripple"></i></span></a></div></div><div class="about-one_image-column-two col-lg-6 col-md-12 col-sm-12"><div class="about-one-image-inner-two"><div class="about-cicle_layer-two"><img${ssrRenderAttr("src", _imports_0$1)} alt=""></div><div class="about-one_image-two"><div class="about-one_counter-block"><div class="dots-layer" style="${ssrRenderStyle({ "background-image": "url(./../../public/images/icons/about-dots.png)" })}"></div><div class="about-one_counter-number"><span class="odometer" data-count="12"></span></div><div class="about-one_counter-text"> years of <br> experiences </div></div><img${ssrRenderAttr("src", _imports_1)} alt=""><div class="about-one_award"><div class="about-one_award-inner"><div class="about-one_award-icon"><img${ssrRenderAttr("src", _imports_2)} alt=""></div><strong>Best Awarded Company</strong> We adapt our delivery to the way your work, whether as an external provider. </div></div></div></div></div></div></div></section>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Job/About.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$3;
const _imports_0 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHEAAACABAMAAADOnptfAAAAG1BMVEXu7u4AAABZWVl3d3fQ0NA7OzsdHR2UlJSysrI0I8BeAAAACXBIWXMAAA7EAAAOxAGVKw4bAAABAklEQVRYhe3Sv4+CMBwF8BcsP1YMyXXsGc8ZF2bOoLMxh3E8ITCrf4Ek/uH3bSVsEIYb3yemSR99aS0ARERERERENGIFeAbe1QBqCXRPuGB3vWDRrieKC1m9NfgqSpncn6q2oQRlkeXZqxwvqnOFfWuURpcD/q9/lNAGCYJb7cIR4fqEx97Y/WSRquzYB0Fav88+5iRbycKospP7h8tsIK2smDjt0NxoOwmSoankb8R6RlNuR4ZNMzQPRzTFdsZp3RDqLu2bsmWYvJ9MNiO5Sul8p57umweDaE5TXt9nDrTu5wJ7YU0+47S79kc+Hbkfd1zfhHEcp/Y7IiIiIiIiov/2BxyXKP/Fw7lIAAAAAElFTkSuQmCC";
const _sfc_main$2 = {
  __name: "Process",
  __ssrInlineRender: true,
  props: {
    refrences: Object
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Swiper = Swiper;
      const _component_SwiperSlide = SwiperSlide;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "process-one" }, _attrs))}><div class="auto-container"><div class="process-one_inner-conatiner"><div class="four-item-carousel owl-carousel owl-theme">`);
      _push(ssrRenderComponent(_component_Swiper, {
        modules: ["SwiperAutoplay" in _ctx ? _ctx.SwiperAutoplay : unref(Autoplay), "SwiperEffectCreative" in _ctx ? _ctx.SwiperEffectCreative : unref(EffectCreative)],
        "slides-per-view": 4,
        loop: true,
        scrollbar: { draggable: true },
        autoplay: {
          delay: 8e3,
          disableOnInteraction: true
        },
        "creative-effect": {
          prev: {
            shadow: false,
            translate: ["-20%", 0, -1]
          },
          next: {
            translate: ["100%", 0, 0]
          }
        }
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<!--[-->`);
            ssrRenderList(__props.refrences, (slider) => {
              _push2(ssrRenderComponent(_component_SwiperSlide, { class: "slide" }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<div class="process-one_block"${_scopeId2}><div class="process-one_block-inner"${_scopeId2}><div class="process-one_image"${_scopeId2}><img${ssrRenderAttr("src", _imports_0)} alt=""${_scopeId2}></div><div class="${ssrRenderClass([slider.color, "process-one_year"])}"${_scopeId2}>${ssrInterpolate(slider.year)}</div><h5 class="process-one_heading"${_scopeId2}>${ssrInterpolate(slider.title)}</h5><div class="process-one_text"${_scopeId2}>${ssrInterpolate(slider.description)}</div></div></div>`);
                  } else {
                    return [
                      createVNode("div", { class: "process-one_block" }, [
                        createVNode("div", { class: "process-one_block-inner" }, [
                          createVNode("div", { class: "process-one_image" }, [
                            createVNode("img", {
                              src: _imports_0,
                              alt: ""
                            })
                          ]),
                          createVNode("div", {
                            class: ["process-one_year", slider.color]
                          }, toDisplayString(slider.year), 3),
                          createVNode("h5", { class: "process-one_heading" }, toDisplayString(slider.title), 1),
                          createVNode("div", { class: "process-one_text" }, toDisplayString(slider.description), 1)
                        ])
                      ])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            });
            _push2(`<!--]-->`);
          } else {
            return [
              (openBlock(true), createBlock(Fragment, null, renderList(__props.refrences, (slider) => {
                return openBlock(), createBlock(_component_SwiperSlide, { class: "slide" }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "process-one_block" }, [
                      createVNode("div", { class: "process-one_block-inner" }, [
                        createVNode("div", { class: "process-one_image" }, [
                          createVNode("img", {
                            src: _imports_0,
                            alt: ""
                          })
                        ]),
                        createVNode("div", {
                          class: ["process-one_year", slider.color]
                        }, toDisplayString(slider.year), 3),
                        createVNode("h5", { class: "process-one_heading" }, toDisplayString(slider.title), 1),
                        createVNode("div", { class: "process-one_text" }, toDisplayString(slider.description), 1)
                      ])
                    ])
                  ]),
                  _: 2
                }, 1024);
              }), 256))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></section>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Job/Process.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_3 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "Team",
  __ssrInlineRender: true,
  props: {
    teams: Object
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "team-one" }, _attrs))}><div class="auto-container"><div class="sec-title centered"><div class="sec-title_title">Team Member</div><h2 class="sec-title_heading">Passionate Personalities, <br> <span class="theme_color">Versatile</span> Brains</h2></div><div class="row clearfix"><!--[-->`);
      ssrRenderList(__props.teams, (member) => {
        _push(`<div class="team_one col-lg-3 col-md-6 col-sm-12"><div class="team_one-inner wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms"><div class="team_one-image"><img${ssrRenderAttr("src", member.image)} alt=""><div class="team_one-content"><h5 class="team-one_title"><a href="team-detail.html">${ssrInterpolate(member.name)}</a></h5><div class="team-one_designation">${ssrInterpolate(member.role)}</div></div><div class="team_one-overlay"><div class="team-one_overlay-content"><div class="team_one-text">${ssrInterpolate(member.descriptoin)}</div><a class="team_one-more" href="team-detail.html">Read more</a></div></div></div><ul class="team-one_social"><li><a href="https://www.facebook.com/" class="fa-brands fa-facebook-f fa-fw"></a></li><li><a href="https://www.twitter.com/" class="fa-brands fa-twitter fa-fw"></a></li><li><a href="https://dribbble.com/" class="fa-brands fa fa-dribbble fa-fw"></a></li></ul></div></div>`);
      });
      _push(`<!--]--></div></div></section>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Job/Team.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_4 = _sfc_main$1;
const _sfc_main = {
  __name: "[job]",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    const services = jsonData.services;
    let service = [];
    service = services.filter((item) => {
      return item.name === route.params.job;
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_LandingHeader = __nuxt_component_0;
      const _component_JobSlider = __nuxt_component_1;
      const _component_JobAbout = __nuxt_component_2;
      const _component_JobProcess = __nuxt_component_3;
      const _component_JobTeam = __nuxt_component_4;
      const _component_LandingFooter = __nuxt_component_5;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_LandingHeader, null, null, _parent));
      _push(ssrRenderComponent(_component_JobSlider, {
        name: unref(service)[0].name,
        image: unref(service)[0].image,
        title: unref(service)[0].title,
        content: unref(service)[0].content
      }, null, _parent));
      _push(ssrRenderComponent(_component_JobAbout, {
        about: unref(service)[0].about,
        name: unref(route).params.job
      }, null, _parent));
      _push(ssrRenderComponent(_component_JobProcess, {
        refrences: unref(service)[0].references
      }, null, _parent));
      _push(ssrRenderComponent(_component_JobTeam, {
        teams: unref(service)[0].teams
      }, null, _parent));
      _push(ssrRenderComponent(_component_LandingFooter, null, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/jobs/[job].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_job_-82d8e8bc.mjs.map
