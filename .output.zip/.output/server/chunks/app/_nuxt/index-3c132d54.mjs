import { _ as __nuxt_component_0, a as __nuxt_component_5$1 } from './Footer-9b3e5ea3.mjs';
import { Swiper, SwiperSlide } from 'swiper/vue';
import { _ as __nuxt_component_0$1 } from './nuxt-link-563b35af.mjs';
import { useSSRContext, ref, mergeProps, unref, withCtx, createVNode, createTextVNode, toDisplayString, openBlock, createBlock, Fragment, renderList } from 'vue';
import { Autoplay, EffectCreative } from 'swiper/modules';
import { ssrRenderComponent, ssrRenderAttrs, ssrRenderList, ssrRenderStyle, ssrInterpolate, ssrRenderAttr, ssrRenderClass } from 'vue/server-renderer';
import { _ as _export_sfc } from '../server.mjs';
import 'ufo';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'h3';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import '@formkit/core';
import '@formkit/utils';
import '@formkit/inputs';
import '@formkit/rules';
import '@formkit/validation';
import '@formkit/i18n';
import '@formkit/themes';
import '@formkit/observer';
import 'defu';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'klona';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'http-graceful-shutdown';

const _sfc_main$6 = {
  __name: "Slider",
  __ssrInlineRender: true,
  setup(__props) {
    const sliders = [
      {
        mainImage: "background-image:url(./../../public/images/main-slider/2.jpg)",
        patternImage: "background-image:url(./../../public/images/main-slider/pattern-1.png)",
        title: "We are Business Solution",
        head: "Prosper in this volatile <br />market funding.",
        description: "We place you at the centre of international networks to <br /> advance your strategic interests",
        link: "Contact one of our experts"
      },
      {
        mainImage: "background-image:url(./../../public/images/main-slider/2.jpg)",
        patternImage: "background-image:url(./../../public/images/main-slider/pattern-1.png)",
        title: "We are Business Solution",
        head: "Prosper in this volatile <br />market funding.",
        description: "We place you at the centre of international networks to <br /> advance your strategic interests",
        link: "Contact one of our experts"
      },
      {
        mainImage: "background-image:url(./../../public/images/main-slider/2.jpg)",
        patternImage: "background-image:url(./../../public/images/main-slider/pattern-1.png)",
        title: "We are Business Solution",
        head: "Prosper in this volatile <br />market funding.",
        description: "We place you at the centre of international networks to <br /> advance your strategic interests",
        link: "Contact one of our experts"
      }
    ];
    const mainSlider = ref(null);
    const onSlideChange = () => {
      mainSlider.value.classList.add("active");
    };
    const onSlideBeforeChanges = () => {
      mainSlider.value.classList.remove("active");
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Swiper = Swiper;
      const _component_SwiperSlide = SwiperSlide;
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "slider-two" }, _attrs))}><div class="single-item-carousel owl-carousel owl-theme">`);
      _push(ssrRenderComponent(_component_Swiper, {
        modules: ["SwiperAutoplay" in _ctx ? _ctx.SwiperAutoplay : unref(Autoplay), "SwiperEffectCreative" in _ctx ? _ctx.SwiperEffectCreative : unref(EffectCreative)],
        "slides-per-view": 1,
        loop: true,
        effect: "creative",
        scrollbar: { draggable: true },
        navigation: "",
        onAfterInit: onSlideChange,
        onBeforeDestroy: onSlideBeforeChanges,
        autoplay: {
          delay: 8e3,
          disableOnInteraction: true
        },
        "creative-effect": {
          prev: {
            shadow: false,
            translate: ["-20%", 0, -1]
          },
          next: {
            translate: ["100%", 0, 0]
          }
        }
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<!--[-->`);
            ssrRenderList(sliders, (slider) => {
              _push2(ssrRenderComponent(_component_SwiperSlide, {
                class: "slide",
                key: _ctx.slide
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<div class="slider-two_image-layer" style="${ssrRenderStyle(slider.mainImage)}"${_scopeId2}></div><div class="slider-two_pattern-layer" style="${ssrRenderStyle(slider.patternImage)}"${_scopeId2}></div><div class="auto-container"${_scopeId2}><div class="slider-two-content"${_scopeId2}><div class="slider-two_inner"${_scopeId2}><div class="slider-two_title"${_scopeId2}>${ssrInterpolate(slider.title)}</div><h1 class="slider-two_heading"${_scopeId2}>${slider.head}</h1><div class="slider-two_text"${_scopeId2}>${slider.description}</div><div class="slider-two_button-box"${_scopeId2}><a class="btn-style-two theme-btn btn-item" href="#"${_scopeId2}><div class="btn-wrap"${_scopeId2}>`);
                    _push3(ssrRenderComponent(_component_nuxt_link, { to: "/contact" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`<span class="text-one"${_scopeId3}>${ssrInterpolate(slider.link)} <i class="fa-solid fa-arrow-right fa-fw"${_scopeId3}></i></span><span class="text-two"${_scopeId3}>${ssrInterpolate(slider.link)} <i class="fa-solid fa-arrow-right fa-fw"${_scopeId3}></i></span>`);
                        } else {
                          return [
                            createVNode("span", { class: "text-one" }, [
                              createTextVNode(toDisplayString(slider.link) + " ", 1),
                              createVNode("i", { class: "fa-solid fa-arrow-right fa-fw" })
                            ]),
                            createVNode("span", { class: "text-two" }, [
                              createTextVNode(toDisplayString(slider.link) + " ", 1),
                              createVNode("i", { class: "fa-solid fa-arrow-right fa-fw" })
                            ])
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                    _push3(`</div></a></div></div></div></div>`);
                  } else {
                    return [
                      createVNode("div", {
                        class: "slider-two_image-layer",
                        style: slider.mainImage
                      }, null, 4),
                      createVNode("div", {
                        class: "slider-two_pattern-layer",
                        style: slider.patternImage
                      }, null, 4),
                      createVNode("div", { class: "auto-container" }, [
                        createVNode("div", { class: "slider-two-content" }, [
                          createVNode("div", { class: "slider-two_inner" }, [
                            createVNode("div", { class: "slider-two_title" }, toDisplayString(slider.title), 1),
                            createVNode("h1", {
                              innerHTML: slider.head,
                              class: "slider-two_heading"
                            }, null, 8, ["innerHTML"]),
                            createVNode("div", {
                              innerHTML: slider.description,
                              class: "slider-two_text"
                            }, null, 8, ["innerHTML"]),
                            createVNode("div", { class: "slider-two_button-box" }, [
                              createVNode("a", {
                                class: "btn-style-two theme-btn btn-item",
                                href: "#"
                              }, [
                                createVNode("div", { class: "btn-wrap" }, [
                                  createVNode(_component_nuxt_link, { to: "/contact" }, {
                                    default: withCtx(() => [
                                      createVNode("span", { class: "text-one" }, [
                                        createTextVNode(toDisplayString(slider.link) + " ", 1),
                                        createVNode("i", { class: "fa-solid fa-arrow-right fa-fw" })
                                      ]),
                                      createVNode("span", { class: "text-two" }, [
                                        createTextVNode(toDisplayString(slider.link) + " ", 1),
                                        createVNode("i", { class: "fa-solid fa-arrow-right fa-fw" })
                                      ])
                                    ]),
                                    _: 2
                                  }, 1024)
                                ])
                              ])
                            ])
                          ])
                        ])
                      ])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            });
            _push2(`<!--]-->`);
          } else {
            return [
              (openBlock(), createBlock(Fragment, null, renderList(sliders, (slider) => {
                return createVNode(_component_SwiperSlide, {
                  class: "slide",
                  key: _ctx.slide
                }, {
                  default: withCtx(() => [
                    createVNode("div", {
                      class: "slider-two_image-layer",
                      style: slider.mainImage
                    }, null, 4),
                    createVNode("div", {
                      class: "slider-two_pattern-layer",
                      style: slider.patternImage
                    }, null, 4),
                    createVNode("div", { class: "auto-container" }, [
                      createVNode("div", { class: "slider-two-content" }, [
                        createVNode("div", { class: "slider-two_inner" }, [
                          createVNode("div", { class: "slider-two_title" }, toDisplayString(slider.title), 1),
                          createVNode("h1", {
                            innerHTML: slider.head,
                            class: "slider-two_heading"
                          }, null, 8, ["innerHTML"]),
                          createVNode("div", {
                            innerHTML: slider.description,
                            class: "slider-two_text"
                          }, null, 8, ["innerHTML"]),
                          createVNode("div", { class: "slider-two_button-box" }, [
                            createVNode("a", {
                              class: "btn-style-two theme-btn btn-item",
                              href: "#"
                            }, [
                              createVNode("div", { class: "btn-wrap" }, [
                                createVNode(_component_nuxt_link, { to: "/contact" }, {
                                  default: withCtx(() => [
                                    createVNode("span", { class: "text-one" }, [
                                      createTextVNode(toDisplayString(slider.link) + " ", 1),
                                      createVNode("i", { class: "fa-solid fa-arrow-right fa-fw" })
                                    ]),
                                    createVNode("span", { class: "text-two" }, [
                                      createTextVNode(toDisplayString(slider.link) + " ", 1),
                                      createVNode("i", { class: "fa-solid fa-arrow-right fa-fw" })
                                    ])
                                  ]),
                                  _: 2
                                }, 1024)
                              ])
                            ])
                          ])
                        ])
                      ])
                    ])
                  ]),
                  _: 2
                }, 1024);
              }), 64))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></section>`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Slider.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$6;
const _imports_0$2 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIwAAAB4BAMAAADS7QcCAAAAG1BMVEXu7u4AAACUlJTQ0NCysrI7OzsdHR13d3dZWVm/YKd/AAAACXBIWXMAAA7EAAAOxAGVKw4bAAABQUlEQVRoge2TvW6DMBRGb+Pws7qFwFjeAJZ2haGdQXmBWkgkI3kDWPrcvXbApgOBsZW+M1jIHzq+vraJAAAAAAAAAACA/0GW67EjEt9xyV9C8VjUNvtQF5utc5RaE56IPCkjPVOxosnnTEgpa5utF2M0FWtu5/eTngkTCp5t5iX5Z2SzNbxYLyyunalgNJWrvKpt9lTTIXHZCn4/siZsWRNzUb3Z1bnLXcZ7S1y2iv41KzsSKXd20DOB7cNdE0Yue6QRVz4pXnP+VQ0uY7JhkT3QeF+/NEfZLjWHmPZpspKWm/LTeKm51bRvUw3fjdS1ceybV6fxWLGvxXeNmg6VN1G8OI1Rqo0Dn9vYuetXtNo0Z6G5iVvXb6Hxpwuvl2/6OStMpf7WY3Ca6fkFuhdv0ZxlRrP5NAEAAAAAAAAAgD/CD2cgQZuQXdNNAAAAAElFTkSuQmCC";
const _sfc_main$5 = {
  __name: "Features",
  __ssrInlineRender: true,
  setup(__props) {
    const features = [
      {
        link: "/home",
        image: "./../../public/images/icons/feature-1.png",
        title: "Data Management"
      },
      {
        link: "/home",
        image: "./../../public/images/icons/feature-2.png",
        title: "Reporting Solution"
      },
      {
        link: "/home",
        image: "./../../public/images/icons/feature-3.png",
        title: "Data training and"
      },
      {
        link: "/home",
        image: "./../../public/images/icons/feature-3.png",
        title: "Data training and"
      },
      {
        link: "/home",
        image: "./../../public/images/icons/feature-3.png",
        title: "Data training and"
      }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0$1;
      const _component_Swiper = Swiper;
      const _component_SwiperSlide = SwiperSlide;
      _push(`<!--[--><section class="featured-one"><div class="auto-container"><div class="row clearfix"><!--[-->`);
      ssrRenderList(features, (feature) => {
        _push(`<div class="feature-block_one"><div class="feature-block_one-inner">`);
        _push(ssrRenderComponent(_component_nuxt_link, {
          to: feature.link
        }, null, _parent));
        _push(`<span class="color-layer"></span><span class="feature-block_one-icon"><img${ssrRenderAttr("src", feature.image)} alt=""></span><h5 class="feature-block_one-title">${ssrInterpolate(feature.title)}</h5></div></div>`);
      });
      _push(`<!--]--></div></div></section><section class="clients-one"><div class="clients-one_pattern" style="${ssrRenderStyle({ "background-image": "url(./../../public/images/background/3.jpg)" })}"></div><div class="auto-container"><div class="row clearfix"><div class="clients-one_title-column col-lg-4 col-md-12 col-sm-12"><div class="client-one_title"> Join over +15,000 happy clients! </div></div><div class="clients-one_carousel-column col-lg-8 col-md-12 col-sm-12"><ul class="sponsors-carousel-two owl-carousel owl-theme">`);
      _push(ssrRenderComponent(_component_Swiper, {
        modules: _ctx.modules,
        "slides-per-view": 3,
        "space-between": 20,
        loop: true,
        effect: "creative",
        autoplay: {
          delay: 8e3,
          disableOnInteraction: true
        },
        "creative-effect": {
          prev: {
            shadow: false,
            translate: ["-20%", 0, -1]
          },
          next: {
            translate: ["100%", 0, 0]
          }
        }
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<!--[-->`);
            ssrRenderList(10, (slider) => {
              _push2(ssrRenderComponent(_component_SwiperSlide, {
                class: "slide",
                key: _ctx.slide
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<li class="slide-item"${_scopeId2}><figure class="client-one_image-box"${_scopeId2}><a href="#"${_scopeId2}><img${ssrRenderAttr("src", _imports_0$2)} alt=""${_scopeId2}></a></figure></li>`);
                  } else {
                    return [
                      createVNode("li", { class: "slide-item" }, [
                        createVNode("figure", { class: "client-one_image-box" }, [
                          createVNode("a", { href: "#" }, [
                            createVNode("img", {
                              src: _imports_0$2,
                              alt: ""
                            })
                          ])
                        ])
                      ])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            });
            _push2(`<!--]-->`);
          } else {
            return [
              (openBlock(), createBlock(Fragment, null, renderList(10, (slider) => {
                return createVNode(_component_SwiperSlide, {
                  class: "slide",
                  key: _ctx.slide
                }, {
                  default: withCtx(() => [
                    createVNode("li", { class: "slide-item" }, [
                      createVNode("figure", { class: "client-one_image-box" }, [
                        createVNode("a", { href: "#" }, [
                          createVNode("img", {
                            src: _imports_0$2,
                            alt: ""
                          })
                        ])
                      ])
                    ])
                  ]),
                  _: 1
                });
              }), 64))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</ul></div></div></div></section><!--]-->`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Features.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$5;
const _imports_0$1 = "data:image/jpeg;base64,iVBORw0KGgoAAAANSUhEUgAAAUgAAAGdBAMAAACCyfecAAAAG1BMVEXu7u4AAADQ0NB3d3c7OzsdHR1ZWVmysrKUlJTCmUChAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAEd0lEQVR4nO3YzW/bNhzHYU2yLR/HJk5ztJEYyDEK0nuEIj2H69DsaAPtdrU3YOd6SPt3j+SPokhFRoGZlwGf5xJFlsWv+C4XBQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP4nynu9+CM6/rDrj98v+8u0evKHE7VI7jBXb8Lx4dIfXD2qT7tsIbfKeJYg7vhc7t3Y44v+ukP45xCFslb9/6X2IWf224tcKdfK+Rodu3ImcvxLuNAUK2WW/upA9yEn8mVb7+FOGeg+mL+zhNnK4Xl8pSSexvUr6UPI1ueaqujZT1Yp9duy3rpeZkr7uCu/Kdv5aqXOduW7uJi9D7eNqlfOh5DXXeU1avFP8bcK3fg0P7m6ql2YlTpfuhBnNvDCHJdtVEwlieuu2T1b/z5krbuQSj24+Hna+yDV0tibNnI8sbmncv9VPEakvdf2GSJmrHcXNV03nLtHNI91XuSwVbcS5sl2KHdsBoYN+bMkeNtfu3Lt3bpK6jXqxYc0HeWThJzJg5SDueq/uvmyCyG1b0ellibkm1chXXtX9tNIrS4mcq3pB+dXErL8/pwzpLe31XPzRYrXKswlK6lQrzVphv1sqp5CyMXXKvm0ztTcnm91YZvb96pWbaKrzMgyw2Qz+OYuhLwt0pCzQfc9TSWRxNw9f2unoG/xefuJun+1JJ4VPmR5VwxCNoPJ6iRXOu56MrD9ivOcXGhn+LfJmbXpJ5N+CohD2lk22+pdDlbZRubGF5tx0Fx23bxNzrSmqsdDrl494inq9G5zmbOTzUZ0aToUXKjxkPuMGwyXKk7pdzsHae5BVerBib0dRuMhDzm3QUX14bPu1+i5LLjmz8elXcc3yaVq0M20HUbjIe9/f8y3DXLJ+t3WQQZ0WMeTcWKaMNkzzNzXjgwctwQtM6Zcd32t8lvIrYSZpX1QK53s0w5uGB0NaSbVh4wh6+6ZW6nBZIkMzF7uOm7vUh7haEhT8+ke/kQ67M03UryS89t433pQZ2W8Wa9UcDkacpq1U/owdTd6y66Zm2heLO0usYna+4chZ3lC3nyOQ+67UR72L3HIqXIzd1+3R0OW3x8yhiy7Pueaex7my9Hm3toiSxX3wCMhu71ypubWYaO7tBUZ9hO+j4YBVLhH2BS2Yw73X68HztT3mlWegbPtNreLdMbwb1tVV6OFHVSuC8yGy/dIyJlvoDbPm9i+e+G69C834bybippoGWz9jkwPNkIjIWuZA64zvdPa19hl/c4tJPEvE+b8xZ/lSzThVF2J++FLwcg8ad6R74q/dKbXh+4HAVufOgyDZfpDgc/WL0qbH4X0v4Xk2vSuw91qFYXszoeWLXUocdjeIyH9Myb7+lO4feNFkUwo9t6N20+GUiZ9pa4GhY8ti+4Hq0GNnyD8xDdLQ7rz/TodDaFKpfuG0bX76lH9epcrIwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGD8C5xKofS2InkyAAAAAElFTkSuQmCC";
const _imports_1$1 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADsAAAAzCAYAAAApdnDeAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNS1jMDIxIDc5LjE1NTc3MiwgMjAxNC8wMS8xMy0xOTo0NDowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTQgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjQzQUZCREQ5OUJEQzExRURBN0VGQ0MzRjc1QTRGQzkzIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjQzQUZCRERBOUJEQzExRURBN0VGQ0MzRjc1QTRGQzkzIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6NDNBRkJERDc5QkRDMTFFREE3RUZDQzNGNzVBNEZDOTMiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6NDNBRkJERDg5QkRDMTFFREE3RUZDQzNGNzVBNEZDOTMiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5+ZclrAAALOklEQVR42rRafXBVxRXffbwACeQlBanBli8pkIAfFBScysd0ajulgEMFIQ0tH1YawWKLMHX4o6PjVAuNoIBQtAVCypcUW8ePKtQ6ov2wDAIqRagSJYDjNCrkJUAK5G1/597z8vbt3fuVqS/zy92zd/fcu3vOnj3n3JVKKRHlN3dwk1BS3KSkXIXrV4AEIDxI6LR0rplc3UfAr4DN1C6jt+M2GQsfpy4hPc/JWJ8trXwO1xWJpIj3WwGMAtqADJCbKcng/0rkXk77DUV1LeqeQsdWt7V0eqgssxwft06js9yV1B+c65PlYfLJ/mIOVpZwoTsYtbYz1F/O9oKiffYP4f71IAuEcPsrfcYMPlYewj5w5Z30XL/Yg3WZdOMHtIJBN2AGUKC9XAY4gNKb+oM06bYxL5n34oZkzBeGamL5iAoUTwF/9peuzJ90Y+IjD5Y79wfOcNVPgIcss3kaKvxlHxVsQN0I3PsSqLRz00e6/MwuaP8Mit/WpPsm6qeieCJUhQ0JJ2Ko8GguPMcPKWOGi/H/NnoBoAUoFdJXBV9jssIjHftafZUH+iLoauC3KI8E3sC9AhFBhXU1TsRQ40XMbC0/pIIftBL4I4p/QH0LUGiqsKbGu3iQd4UMkn6TAbL+u1D3HZSfBOYBNaDL0Ha+sqiwaTt07Yo02DlDmsp4fZ4F9vFDxjlrUDp/WYZYFvJSgJE6iXvvofhN3CwPMkigx/Ek1RhGbiWT37AaxwAJR5Ss3MuFSp7J8UBnYGuWfwRLnP1V8cv8KWS7ucztuxr9u3P7tijrNJYaw5nYCQaDBa0XKXazCj/ED1keNJuWfZba7Ef7DcAAUJsDpHuJ9+rORv8kt70cqMIWNfa1xncMarrO2fylKEfH54F5zITW0s3A68ARzzbhP0jNIMk7QQ8AZoHurVxpf2JIty23NCzORHb5iGiW2DPYeVc39QbDMcAc4RoF6vXY5qOpRbMq0kQMBp5lZlVeZ0KK3CvkS9fjDGDNAdtRrgQaUftLR+JSHGcOfbj/aeueKqJZ4jynorp/04/A7MeouEblv+g+4P7aY6mXmNk4TY2nAacsKnxFiAqb0vke/v8V9MPAUtBLQf8b+BvoKWj7X5QPB3tM0qtZIt9n1tX4CWbUCBzBza3Azo3vlTRR9ezydGfQDwL3MaNZuDztM5u1ig1KyCB1R4C2snXAHSAngR6LtnN5HT7MbnYkf1jJYAln1fit39SXDNfW61UwTLdCLW+hdcXVHwB3gd5jXaeuMZkb7s9Km8ek2GhtAL0NNEn8IPBzyyBVVGfCVPskM3Ms250DmypBbzc6NoFexvBaPJsv6w4yobzRSsbPmUB5KrAJpWJHtaWYQO0DVFjaJ90SduZtPVJ0YincwA2eAeYDw2GcSuuOpJYpP4PgHeRy4a61NnY62pS7J7Y5FlyKvobV7QP6Rce7wkBBL4JGjUW5JSSka3XFHO5M+IV45/i6uPZYSX1A9EM/2ifLNBXOGpyFwEVSe+Mlk1DhMWyQxiuHdiz+Yzzw3Wj/UxSPBoV05Mzw4HoA/Xy2GmrS4FVju5WmgdT7DJIaLQRW+8wmRTYDTBXkdbYWWIByvSFdWuu1vpY83xh9xnUTgA8tkVm2/2fAEmCTat+wNcZ55toe4hF64bIa/T4F6gwVXqBczcqY0lFZI+fyJi/qBPAqu5xnhL5Xe/dkffmcBqajcDvqinwscWfX/xYb3VDS3T3iZSpcZr2Z4Q7gXk2FBVvRvnbpOPvhF9q3LyneDUq/+Dkj3P73hBBLPNDx8GjAbkzclgi01fYHXeQX7mZx+sm6X7Tus24f1R4LhwxSdDD9omnnceB9aEqK9n7HGquYaqw9SEZw+v2ciYQlpLOrcJT0i7RGW7ewe/ty1vB2RI21F5QRB/m5ZRCLgL+zQdV/tJV243IPtPkWrnuSkVRYxMog2pz+zzODSJnKAkPKykkUSHGBc167B1ZfmJrMk0xIAKxC1koMf9iWQRRKxlbh88Awf5/YqRjN4ei2hM/2Ek2FI6lgaAbRM1GxkuAydPH9kxJ2QJdEJBUW0fI8QSooIqzVEGciNINo/RwjRU+K0alPMq9zhDxOpMxE7EFKX+mGZBAL0e5R4EqvuygvcLMZ7Cnek9QZRldjGWykDBXWeJcwXRSowtLXTTU1i4xTdYgak3v5YP36wjVJnwScClTjKMk1u0EiJ5/SsfVxVdhnnaZ5iykz1LgTh4irnK2Jrto+m01qXWZmCasaR88g+m03FAjUgj5n7tWh/f0ziOeVFlhoD6T8NAUsk9iDas16UFn3rZGZ9AzafiNmEP2key6yMxGWBA+3xD30D2ok0Y/Q6yquPND+LcZXhdvXoYrsTORebAxoyobc70RN0Zz+IEtM708xcF+0yYDHJeZViHaTgR7OtyjUZxtTFnHK7Io0uV77mOEE/H/Ax0AVZAN9i3QvO8G19PWYKP06H8XngZfCnJEIGUQKRmqUYTy1Nuv5W1R7lPIXYAoqbqs7ktry/WFpUuVRAarxMT9oZt48uy9JIdzJAAPVwC/ygTLWYQcziJQBHcTqShb+F5zAn8MBwGnjW498lst385XiP1F1XXqiV40dY0Ip1yWCPk1S1kE4AfsC5Za7uF/UpZ+B6s8DX6YvlbBBhsSt7zvaKZ1EwO+43UEO8vP6JWuPpRpml6dPoeImZroc/ylHvAbXF3zcxRW4T59GrjS2izrQQ5W7JTQbBoYcmC8yPUW4SfAXlHSWUauRgSR0iplBRNwql/L9MzafIckzuwqVNVDhe7b8K7W66to0pUpmVg5PT99xKLXT6vRL55P/KUMFLzBNBqLYYnVfoYwt6P4wdDSZEx0EqHDcDKJwv8qftHl/ko4GzapI00JvplnFYJNQ4ULev8gIlT11MNUybWSzcexHmMd+CJ+ohOyOa1f/Iz55x4bK0f9qXAu4TRr3N+HaD23vpf1TPzYUiARZYvkGJ9ryLDxdP1xX6Eq27t3UuR8MS5OJXjnz2vTybe+k7qu8Pl2Nhk/w0YARHfSYwpz+o+2pU/c+fc3vp1wNeNQ3nLSqsfQk7833kPqhr5nXpD/mdfi17W+n/jHjq2ma5TnAc5i1WzOeQ10e6TaiXTHadO3AAS7q8ylQBLqnKyGZf7ArUMIyUPIn1hZ63MKJPBMvY70moL5zyUhh1iajw17U9wqWruyIdLNrao+zfUjxM3LeY33LMb2qKMcMth5O0fmlxZyPfYfqdh5ITULHjXyG4j+0h8X0h6NkEDfh/lg++VYTI4OYk6otajMG7nH4t72dogMaK9Bg6PQR6UO3j0yX7tpf/EMKpZg5fXx6i0+uXGFY0jbPkZ3wDOIWZ6m4tqEyZgYxWqJBWNas/sN6XUMfqTNStmKtjKf9kK0mnT2s0g5Kvga8gnV4FNf1Gel4ZcUhVpjoPqh/GuUbgdeBcfmHNWWEdeo96OmXsWh4vND/AAnW60I0uhsz2ZXzOOucQx1wE5V7iIMOex1z1FuKB0DvUK5XdT5CBnGJcj883ejwle4xoEhJcL/0i82dNHjIsCO4025oprW0AbM9iGdvMfBrJ02Zk+7NmN0hoHuhvD/j+tumVEozCTmJIh4+wtuG+9VouyH0GG2ghP2tsNAlu6YwfLDZ33dHN9MgH9G2ir3KdQ9pW2r0nP9NONkCchhGZSjQSIhp2os9ju2KvqqfNQfTIRUOaSN4sHG+CNBZ4yfRmb6eUZg23kFOjci/PcvHAMhV7G5YYopA1oHe4WQW/r8ZRLv6SuO0TNSRMsNm/gxIkdEg0F9X7pY0hL/ulTLzFk6VHBd0qBIeESSwv4MZxABLLEMtsD7o/wkwAF38ZXESVypqAAAAAElFTkSuQmCC";
const _imports_2$1 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADEAAAA3CAYAAAClxaIBAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNS1jMDIxIDc5LjE1NTc3MiwgMjAxNC8wMS8xMy0xOTo0NDowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTQgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkNBMEZGMkVCOUJEQzExRUQ5MEEzODNGNjAzNTU1MzNBIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkNBMEZGMkVDOUJEQzExRUQ5MEEzODNGNjAzNTU1MzNBIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6Q0EwRkYyRTk5QkRDMTFFRDkwQTM4M0Y2MDM1NTUzM0EiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6Q0EwRkYyRUE5QkRDMTFFRDkwQTM4M0Y2MDM1NTUzM0EiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz4XLUZPAAALG0lEQVR42rRaC3BU1Rk+J0YgG7MBLHboABYSUkIgBIMgz9ahg28Qw0MgRBIlWip92qpDW411VGx1CFYe4SkJWiIG0hYrYlpLaREMEMDwGIQpgihQNbsLC03C3n7/vf/Nnnv37u7dBHfm5jv3/P85OY//ec6VmqaJeL8HM3xCSxJCk/RIA/EeksJaZp4Q8ZjlKKglSbNNMnANsBC4CzgJeJboJv/Ozakxx5ck3PyktawPwqxXyyJcJtTMOhsKmmSY71VgIXAvcATwXaJb+OP83E3CPnh1oPZB2ycVMQFrG2AR0AfMB24B5jq2i/FLdjP+8OCldSDCaSek0wQKAbnAWvD+i9sMAk4DdgH6uY8WXowKwFrgv6l6eMHFviiXQtTO11envhyxvm50oqS/zyrHFvm3l6W1LkksBs5XdOEnoOeBPof5/gNcBCwHTgL9WfANYv4PgWuAS8J6J7cDv9/whqclYZ1opyiRRs4HvgfMQv0R0BcB5wArgVnAvsBybleLv4PB3w34AvBm4BL+30NBnw8cB7wtYZ3ogChdBJ4F3gA8Bt6BoL/CAyJdOCZITITYCjxKoga+J2hcwCeBnYCvAvPr30xtAP073H9TVHF6+EbfZDTKwNZJzVx9KToiSiHgNOBw4CHQc0Jhk/wK8FHlXQNdKmZ4C3AiMLT7rVSRP+3iZtDJ/C6EKD0Rodg/6OPrB+ZtmGU/Ib82qzQQdA+wGXgAmA38G/Al4A5SbnBdC/4RpIbAYmALcIAwdmwc9/90hImd19vXWZDFEJiAED/H0xvPdRo90kC0vI7qRNu7UpbGu0Y8ZtmKy3gRJoEeBG7nCTwKHA9827RO4CNl3QEsAd4BJHHfyyI9lBeoMkJlH+nV9CSYn8Mzd/nJ9JVU+VCGLxPvsgOiFIIoaCwa24A9QfeAPhn0GuAzwKdCFm8vSf6bbZ79TtC3gF65pzq1KG9G8D28j0f9NQeqPKHwJHo3vYPK25adTJelfX09UD6JJ8UaWnQs1EB9GehPA31okwxMVSYwFAgLJG8B/ynw/wi4WWnfAPqQPRtSZd7M4M143402K1C3CeV3G1/zXCGdaFZ2pj+eFGzdUjDUtdMqkXn8A7Cz4igrWPy8wIWKPvUA7gYms2MbBdzEuJP/VxnoNUNnBEdCoXfmFgapbi4oc8FzPLs4ODYZDFe0sGduYSV9Z/Wx9D+ZYy7K9icSK40DdgI+zgMLIhY6A/p9zLdb6eNBmgDoE/BGYpcG9APJK49kvl0ca81EHU1sgGaY7BtQ3oinPNkcmM1v1JZk+dpESR18AlapXhhWx6SnMYaUPrpyu0ZuF2DsrgSZLYweAujCUcDRnAeCqTyGnm2xE/QhHYyHKaqkWeoxTfsc3CVSSGAdDyQAeg9gHbftq/RRqRk7dgBvLwHv4n6eU/6X6eDepj+DZwdJb3qRPnH9L2VpnyZSkHtRmbXiRPoxJ489e6A/EQdH2AtYCrwJ9LtAnwf6UsOhiRMhw6Ga7Um2KxRj8CLwcYW+mWIq6IOEPvQJkeFJguOUYiue9YfXePYkKeJ0QU+AMn15jrFTYqJ0GvAb1N/N9GdMR6UJ3aFOVNqtAH86cAywD+uS2W9v9i/7Wf8WcJtbD631/IwmYImdsAufIYPLQQf7irN80yJjJ9dhtzV8p6xNiG9wsFcG9AFrgcMUY0DKTA73lOLhSaT3cP8TuK6U9Adm9Zwl7NCsoYGXS9ezVaIcoKdIaptACEge9IsEMrgS8M0A1lP/wNHAj4Afgk4x0Erwf6G0o/yiAPQq0yo1vO45B1F6n53v7ZFJkTVWauZYyYwS38d7N5so/RT0RQlkcNmc+HRhbAR+C/h3DrdfAJKMH+dodwS3uwy8G1jH0pDB/4tiq9NRQ3Elg+vMA/ku3scLeow451ZBE3AvSsksEl8Ce/LACoCfaWTvDStG/mEg8B4O/oi/BPQUnsAU7ELKwSpPb46rNsLBDbCKk3TIY43AS6w75D1IOGuwX1317iin8Uqf4aAtmijRQFKM5F98DlzJDo7opHdvgv+v3I4cXSC8g3IkcB3qM2mn8ORoxgKOwUPG54hzjh0Ouy/ppjXHfypENllGtUrr8bcwhigFOMyepPHmATcBh4NazfxVnPh8APw26L8QZJLDi7YB5emDioJm+ybOFK35hBaZwZn1ZYA+DlYpFWV62xpDlEy8HVgOHAVcC3yRF+MRCpj5EGEsTQC4kA8PPgEu5zD+S5RrUP41yp/SBI+s9vw3QpwczpV0nahq9Oqh+Yxcf0fOlS4CH7JOTGekAS5j85oiLCGJvFHt/2Clp5p2ztW5k5LB6eI0a5C/buZgf4g7p1STyhQwFvOkavU6gxYQ1pAiKtom/glbpWfZcFzSaFzS5qNinTtZ/EQ4VjJrTnMCr4oSyWYTD+BTSh25fVAzUk8RbyK2nfMxLmD6eTLH3J8Qrg7PnI8oqROx/iPvA4T35/mjidK8OKLkgNK+ExmAs6z8z4M+zjJRNzsh7LmB8f4/AojSUwi2ctvMsGL/9ZMSiBZFl8AVwMl8niQVvi3A5XEco4c8tpE3ILgT4hq7/sUXJ2mbrfF+hctTUc6JEyuFOIgbDd6JtpW/TFYmjjFoNSWCDx7CdJcHysmOim3IpHj9gHcQRCktjlUyE5nHIAplWqSfiCVKNr8ihV2U3BwoJwm7xzY6bNucPzZ4A7rlMQakIw88oEzAbGfhi2GViinniOJXEhIlfRJRDwMijjJdxUpurBKFEquBA52O++2i5G4nnGYvHc5iE3Nw0awSZXuzgTX6ieNVEKVIxVYzOIfMLoGLEycRodCCQomPgQVuRcmNiU1Sl11zut5yL0qrgB8DZzlMpCv4tjP/qGgL4ChKbp2d2qGjXsQXpQrO4ISRkYlzwG2KqOxm/u8Bzl8tq2RTbKWxiK4TUUSJ/MNcijQ1SmvhKDl/6M7tKHDrT7dFwH/EMgZOopSwYke1UGGrQp78d7aB/IXblHAGN4Lf6Zzpt8Cp4HuNjzbF1RYlwTcyUU8zlJ1YxVaFQo3HKF/SzGN2KbvSQPkUg9ru5yg3D/gr0EkX5rTXwbm/PXXIFcxfwbBAEfaL7gs2osMZFNkC11H4zPfPJPsbbaKxFnhYGOelf3bjV9orSkKJWRx3Ykp+YAgmQKLwOTqcznnDHXTxAfw9eL/i4xUns7ortjFwKUquAkDnlWjmDvbxQEbzBOi3j281R0MU3tAsyX3csDueKPXksgzvmGzfTtBNDHf6QzqlQPGEbSB0EFafYAYXS5Qkl2v0ezpEv4mY2GTN2ZRepj9v1actJbz3lkBHYqV4oqTpi2aUX9bvJqQ1SXOX2YUbdeLJXD9lWCDNPO1WO+tABhdNlJL0W1MHq6S5tLHJmvXI5itWqiUoL+lgrCQSsEofcJmuwu4DXzbKra4V22S8f4j/mxv2e49Mu8n/Y6zAGDMxijOQK7abH1WUzBQ2nlWis6RyLtMnD5l8qHxBk25z7HCn+nVS9V7vYsBilWniqMDXJUp2n3DOTHndipIpTl248wvxPhdyEKVVwLEOItIK/oeB/0zQwQVVE5uIYgfNC8F4E3AYiJeP6e2i1NJ2upiYg+tnnra4FSUziq0wr53c7YRFlKaqn0cYqH9C0U0z7h8SEaV8+j5L0/2PbBXCvcfWv7KZnudfDVNKyfuZkJQ7NOPrGKcvA9q+HGDz2xqiK1rL1wWS+Emhu8Rqb7vE7I7yBC5noo/j6tcLJ5alxJ8E/WCVFuAf0GHZtS6/ooyCUkRfgEi6Ut5J35eArzFkfobhchL/F2AApeWRUORSksgAAAAASUVORK5CYII=";
const _sfc_main$4 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  const _component_nuxt_link = __nuxt_component_0$1;
  _push(`<section${ssrRenderAttrs(mergeProps({ class: "about-two" }, _attrs))}><div class="about-two_pattern-two" style="${ssrRenderStyle({ "background-image": "url(./../../public/images/background/pattern-13.png)" })}"></div><div class="auto-container"><div class="row clearfix"><div class="about-two_image-column col-lg-6 col-md-12 col-sm-12"><div class="about-two_pattern-one" style="${ssrRenderStyle({ "background-image": "url(./../../public/images/background/pattern-12.png)" })}"></div><div class="about-two_image"><img${ssrRenderAttr("src", _imports_0$1)} alt=""><a class="about-two_play lightbox-video fa-solid fa-play fa-fw" href="https://www.youtube.com/watch?v=kxPCFljwJws"><i class="ripple"></i></a></div></div><div class="about-two_content col-lg-6 col-md-12 col-sm-12"><div class="about-two_content-inner"><div class="sec-title_two"><div class="sec-title_two-title"> About Our Company </div><h2 class="sec-title_two-heading"> Choose <span>The Best</span> IT <br> Service Company </h2></div><div class="about-two_text"> An IT firm or MSP who keeps your IT running smoothly at all times is like a plumber who fixes your pipes; that\u2019s what they are supposed to do. Many IT firms struggle. </div><div class="about-two_feature"><div class="row clearfix"><div class="about-two_block col-lg-6 col-md-6 col-sm-6"><div class="about-two_block-inner"><span class="about-two_block-icon"><img${ssrRenderAttr("src", _imports_1$1)} alt=""></span><h6 class="about-two_block-heading"> Moneyback <br> Gurentee </h6></div></div><div class="about-two_block col-lg-6 col-md-6 col-sm-6"><div class="about-two_block-inner"><span class="about-two_block-icon"><img${ssrRenderAttr("src", _imports_2$1)} alt=""></span><h6 class="about-two_block-heading"> Technical <br> Support </h6></div></div></div></div><div class="d-flex flex-wrap"><a class="btn-style-three theme-btn btn-item" href="#"><div class="btn-wrap">`);
  _push(ssrRenderComponent(_component_nuxt_link, { to: "/contact" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<span class="text-one"${_scopeId}>Contact Us <i class="fa-solid fa-arrow-right fa-fw"${_scopeId}></i></span><span class="text-two"${_scopeId}>Contact Us <i class="fa-solid fa-arrow-right fa-fw"${_scopeId}></i></span>`);
      } else {
        return [
          createVNode("span", { class: "text-one" }, [
            createTextVNode("Contact Us "),
            createVNode("i", { class: "fa-solid fa-arrow-right fa-fw" })
          ]),
          createVNode("span", { class: "text-two" }, [
            createTextVNode("Contact Us "),
            createVNode("i", { class: "fa-solid fa-arrow-right fa-fw" })
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></a><div class="about-phone_box"><span class="about-phone_icon fa-solid fa-phone fa-fw"></span> Call for help <br><a class="about-two_phone-number" href="tel:+91-124-3467-2345">91 124 3467 2345</a></div></div></div></div></div></div></section>`);
}
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/About.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main$3 = {
  __name: "Service",
  __ssrInlineRender: true,
  setup(__props) {
    const services = [
      {
        image: "./../../public/images/icons/service-8.png",
        title: "t UI/UX Design",
        link: "/home",
        description: "Our customers get solutions and business opportunities instead of just projects."
      },
      {
        image: "./../../public/images/icons/service-8.png",
        title: "r UI/UX Design",
        link: "/home",
        description: "Our customers get solutions and business opportunities instead of just projects."
      },
      {
        image: "./../../public/images/icons/service-8.png",
        title: "g UI/UX Design",
        link: "/home",
        description: "Our customers get solutions and business opportunities instead of just projects."
      },
      {
        image: "./../../public/images/icons/service-8.png",
        title: "UI/UX Design",
        link: "/home",
        description: "Our customers get solutions and business opportunities instead of just projects."
      },
      {
        image: "./../../public/images/icons/service-8.png",
        title: "UI/UX Design",
        link: "/home",
        description: "Our customers get solutions and business opportunities instead of just projects."
      }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Swiper = Swiper;
      const _component_SwiperSlide = SwiperSlide;
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "services-one" }, _attrs))}><div class="services-one_pattern-layer" style="${ssrRenderStyle({ "background-image": "url(./../../public/images/background/pattern-14.png)" })}"></div><div class="auto-container"><div class="sec-title_two centered"><div class="sec-title_two-title">~ Our Awesome Services ~</div><h2 class="sec-title_two-heading"> Choose <span>The Best</span> IT <br> Service Company </h2></div><div class="services-one_inner-coontainer"><div class="four-item-carousel owl-carousel owl-theme">`);
      _push(ssrRenderComponent(_component_Swiper, {
        modules: _ctx.modules,
        "slides-per-view": 3,
        "space-between": 50,
        scrollbar: { draggable: true },
        loop: true,
        effect: "creative",
        autoplay: {
          delay: 8e3,
          disableOnInteraction: true
        },
        "creative-effect": {
          prev: {
            shadow: false,
            translate: ["-20%", 0, -1]
          },
          next: {
            translate: ["100%", 0, 0]
          }
        }
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<!--[-->`);
            ssrRenderList(services, (service) => {
              _push2(ssrRenderComponent(_component_SwiperSlide, {
                class: "slide",
                key: service
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<div class="service-block_three"${_scopeId2}><div class="service-block_three-inner"${_scopeId2}><span class="service-block_three-icon"${_scopeId2}><img${ssrRenderAttr("src", service.image)} alt=""${_scopeId2}></span><h5 class="service-block_three-heading"${_scopeId2}>${ssrInterpolate(service.title)}</h5><div class="service-block_three-text"${_scopeId2}>${ssrInterpolate(service.description)}</div><div class="service-block_three-overlay"${_scopeId2}><div class="service-block_three-color-layer"${_scopeId2}></div><span class="service-block_three-icon-two"${_scopeId2}><img${ssrRenderAttr("src", service.image)} alt=""${_scopeId2}></span><h5 class="service-block_three-heading alternate"${_scopeId2}>`);
                    _push3(ssrRenderComponent(_component_nuxt_link, {
                      to: service.link
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`${ssrInterpolate(service.title)}`);
                        } else {
                          return [
                            createTextVNode(toDisplayString(service.title), 1)
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                    _push3(`</h5><a class="service-block_three-learn" href="service-detail.html"${_scopeId2}>Learn More</a></div></div></div>`);
                  } else {
                    return [
                      createVNode("div", { class: "service-block_three" }, [
                        createVNode("div", { class: "service-block_three-inner" }, [
                          createVNode("span", { class: "service-block_three-icon" }, [
                            createVNode("img", {
                              src: service.image,
                              alt: ""
                            }, null, 8, ["src"])
                          ]),
                          createVNode("h5", { class: "service-block_three-heading" }, toDisplayString(service.title), 1),
                          createVNode("div", { class: "service-block_three-text" }, toDisplayString(service.description), 1),
                          createVNode("div", { class: "service-block_three-overlay" }, [
                            createVNode("div", { class: "service-block_three-color-layer" }),
                            createVNode("span", { class: "service-block_three-icon-two" }, [
                              createVNode("img", {
                                src: service.image,
                                alt: ""
                              }, null, 8, ["src"])
                            ]),
                            createVNode("h5", { class: "service-block_three-heading alternate" }, [
                              createVNode(_component_nuxt_link, {
                                to: service.link
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(service.title), 1)
                                ]),
                                _: 2
                              }, 1032, ["to"])
                            ]),
                            createVNode("a", {
                              class: "service-block_three-learn",
                              href: "service-detail.html"
                            }, "Learn More")
                          ])
                        ])
                      ])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            });
            _push2(`<!--]-->`);
          } else {
            return [
              (openBlock(), createBlock(Fragment, null, renderList(services, (service) => {
                return createVNode(_component_SwiperSlide, {
                  class: "slide",
                  key: service
                }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "service-block_three" }, [
                      createVNode("div", { class: "service-block_three-inner" }, [
                        createVNode("span", { class: "service-block_three-icon" }, [
                          createVNode("img", {
                            src: service.image,
                            alt: ""
                          }, null, 8, ["src"])
                        ]),
                        createVNode("h5", { class: "service-block_three-heading" }, toDisplayString(service.title), 1),
                        createVNode("div", { class: "service-block_three-text" }, toDisplayString(service.description), 1),
                        createVNode("div", { class: "service-block_three-overlay" }, [
                          createVNode("div", { class: "service-block_three-color-layer" }),
                          createVNode("span", { class: "service-block_three-icon-two" }, [
                            createVNode("img", {
                              src: service.image,
                              alt: ""
                            }, null, 8, ["src"])
                          ]),
                          createVNode("h5", { class: "service-block_three-heading alternate" }, [
                            createVNode(_component_nuxt_link, {
                              to: service.link
                            }, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(service.title), 1)
                              ]),
                              _: 2
                            }, 1032, ["to"])
                          ]),
                          createVNode("a", {
                            class: "service-block_three-learn",
                            href: "service-detail.html"
                          }, "Learn More")
                        ])
                      ])
                    ])
                  ]),
                  _: 2
                }, 1024);
              }), 64))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></section>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Service.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_4 = _sfc_main$3;
const _sfc_main$2 = {
  __name: "Indestry",
  __ssrInlineRender: true,
  setup(__props) {
    const activeTab = ref("prod-mission");
    const tabs = [
      {
        id: "prod-mission",
        title: "Company Mission",
        image: "./../../public/images/resource/choose.jpg",
        heading: "Fingent's Four Pillars of Influence",
        text: "We believe in four pillars of influence that drive our growth. This is ingrained in everything we do We use technology to create a better and smarter environment.",
        link: "#",
        btnText: "Contact Us"
      },
      {
        id: "prod-winner",
        title: "Awards Winner",
        image: "./../../public/images/resource/choose.jpg",
        heading: "Fingent's Four Pillars of Influence",
        text: "We believe in four pillars of influence that drive our growth. This is ingrained in everything we do We use technology to create a better and smarter environment.",
        link: "#",
        // Replace with the link URL for this tab
        btnText: "Contact Us"
      },
      {
        id: "prod-software",
        title: "Using Softwares",
        image: "./../../public/images/resource/choose.jpg",
        heading: "Fingent's Four Pillars of Influence",
        text: "We believe in four pillars of influence that drive our growth. This is ingrained in everything we do We use technology to create a better and smarter environment.",
        link: "#",
        // Replace with the link URL for this tab
        btnText: "Contact Us"
      }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "choose-one" }, _attrs))}><div class="choose-one_pattern-layer" style="${ssrRenderStyle({ "background-image": "url(./../../public/images/background/pattern-19.png)" })}"></div><div class="auto-container"><div class="sec-title_two centered pt-5"><div class="sec-title_two-title">~ Why choose Us? ~</div><h2 class="sec-title_two-heading"> We serve a wide <span>variety</span> <br> of industries </h2></div><div class="choose-info-tabs"><div class="choose-tabs tabs-box"><ul class="tab-btns tab-buttons clearfix"><!--[-->`);
      ssrRenderList(tabs, (tab) => {
        _push(`<li${ssrRenderAttr("data-tab", tab.id)} class="${ssrRenderClass([{ "active-btn": unref(activeTab) === tab.id }, "tab-btn"])}">${ssrInterpolate(tab.title)}</li>`);
      });
      _push(`<!--]--></ul><div class="tabs-content"><!--[-->`);
      ssrRenderList(tabs, (tab) => {
        _push(`<div class="${ssrRenderClass({
          "tab active-tab": unref(activeTab) === tab.id,
          tab: unref(activeTab) !== tab.id
        })}"${ssrRenderAttr("id", tab.id)}><div class="row clearfix"><div class="choose-one_image-column col-lg-6 col-md-12 col-sm-12"><div class="choose-one_image-inner"><div class="choose-one_dotted-layer" style="${ssrRenderStyle({ backgroundImage: `url(${tab.image})` })}"></div><div class="choose-one_color-layer"></div><div class="choose-one_image"><img${ssrRenderAttr("src", tab.image)} alt=""></div></div></div><div class="choose-one_content-column col-lg-6 col-md-12 col-sm-12"><div class="choose-one_content-inner"><div class="choose-one_title">${ssrInterpolate(tab.title)}</div><h2 class="choose-one_heading">${ssrInterpolate(tab.heading)}</h2><div class="choose-one_text">${ssrInterpolate(tab.text)}</div><div class="choose-one_button">`);
        _push(ssrRenderComponent(_component_nuxt_link, {
          class: "btn-style-three theme-btn btn-item",
          to: "/contact"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="btn-wrap"${_scopeId}><span class="text-one"${_scopeId}>${ssrInterpolate(tab.btnText)} <i class="fa-solid fa-arrow-right fa-fw"${_scopeId}></i></span><span class="text-two"${_scopeId}>${ssrInterpolate(tab.btnText)} <i class="fa-solid fa-arrow-right fa-fw"${_scopeId}></i></span></div>`);
            } else {
              return [
                createVNode("div", { class: "btn-wrap" }, [
                  createVNode("span", { class: "text-one" }, [
                    createTextVNode(toDisplayString(tab.btnText) + " ", 1),
                    createVNode("i", { class: "fa-solid fa-arrow-right fa-fw" })
                  ]),
                  createVNode("span", { class: "text-two" }, [
                    createTextVNode(toDisplayString(tab.btnText) + " ", 1),
                    createVNode("i", { class: "fa-solid fa-arrow-right fa-fw" })
                  ])
                ])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div></div></div></div></div>`);
      });
      _push(`<!--]--></div></div></div></div></section>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Indestry.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_5 = _sfc_main$2;
const _imports_0 = "data:image/jpeg;base64,iVBORw0KGgoAAAANSUhEUgAAAHcAAAB3BAMAAADLF8K5AAAAG1BMVEXu7u4AAACysrIdHR2UlJR3d3fQ0NA7OztZWVlC5zHeAAAACXBIWXMAAA7EAAAOxAGVKw4bAAABDklEQVRYhe2PsU7DMBCGj+CkHq0QNx1d8QI1Q+ZElZgbVd0TgZhbkICxUZB4bc62EFlwM4L0f9LvOCd/ujsiAAAAAAAAAPibrENS+8yX/kj04qqJCtmXJuImNmS4b/iZKEjkrnyrfGTxmEfkxvpkmiR35bb9jj/iRvnwz2eksW5DchLKzX1+87scVIih5nc561qfZEli6VqW7qSnVPmsO2q6yNytT1aQ9Nuddr7Koktf02AuyjSareuZ2eNUlnfCXu5M0n44eaH1VKZxNWNst+6Gj6Y+malMtI2433JBizNPvaKHzUS+qul9hjx2e57vuiKhpztXaTVDlvaVL4MJ+dm5jK0MAAAAAAAAAP+VL61jJtBHg8QFAAAAAElFTkSuQmCC";
const _imports_1 = "data:image/jpeg;base64,iVBORw0KGgoAAAANSUhEUgAAAEIAAABCBAMAAAAReh3bAAAAG1BMVEXu7u4AAABZWVk7OzuUlJR3d3cdHR2ysrLQ0NB+RzBvAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAaUlEQVRIiWNgGAWjYBQMZ6BowCTMwODEEAJjogOWABVXJgcGpgoDGBMdMKkZKCUzMHAYN8CYGCoUVJRAGpURTHQVBUXq7AoM7MYFMCaGOzRUnJocGNg6MmBMHH5RYQjC5ZdRMApGwYgCAHMbD+U0OvCaAAAAAElFTkSuQmCC";
const _imports_2 = "data:image/jpeg;base64,iVBORw0KGgoAAAANSUhEUgAAAGYAAABmBAMAAADL8flRAAAAG1BMVEXu7u4AAADQ0NAdHR2ysrI7OztZWVl3d3eUlJRz5pSIAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAA+klEQVRYhe2QwU6EMBCGf2dhl6OVRj0uIp6JUfBYog+w7AbPi09Q30BifG+nrTExmXjR43yHkg79OtMfUBRFURRFUf6b2uGm9GjKI0AXQMc1ugPNPWjsRIVGh+n6Ad3VM+8Wt27501jk+8e31UtzlJxhdnSGj+wUA+/ydtkC2blFtS12A7gs8HTiinT+PXTtLnnNnMUSzxetOBw7Ld8K9LHtLhYt38DtsfK/Onk8Pd/+cCZRSc4AChGgsPffDs8mRxCckAHqOEXlK5+ckAH1ssJOyPrr94SNTU7IupZfE52m9BtjDLDm1xySQ2OPV2PErBVFURRFUZQ/8AnXnCCga439WwAAAABJRU5ErkJggg==";
const _imports_3 = "data:image/jpeg;base64,iVBORw0KGgoAAAANSUhEUgAAAE8AAABPBAMAAABYGoW1AAAAG1BMVEXu7u4AAAB3d3dZWVnQ0NAdHR2UlJSysrI7OzsXDkTgAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAApklEQVRIie3QOwvCMBSG4Y/T2xyke1txjwjOFVrasUisa5ZCxy4Bx6IF/7bHH3B2hfNAIIGX3ACllFK/i4yxhxEINVmUZkc3L6Vt5/oFZEMNxC40byk8U0EFMN55HvkKldBlQ7r1FrhwjIC5eQlh5HG8cjit390R5XshTPhqfHTsnrxwPKSjW2QbvyPx7YJ4wKNzQjgDJX/PCemAdAXlXgiVUkr9lw+N7RaEM3DrJwAAAABJRU5ErkJggg==";
const _sfc_main$1 = {
  __name: "Review",
  __ssrInlineRender: true,
  setup(__props) {
    const reviews = [
      {
        text: "\u201CI To helped the client achieve their goal of calling theattention of mobile network operators. The expert team wasalso able to develop an app with commendable UI/UX. Theclient appreciates their flexibility in terms.\u201D",
        name: "Othman CHARAI",
        post: "Senior Developer",
        image: "./../../public/images/resource/author-1.jpg"
      },
      {
        text: "\u201CI To helped the client achieve their goal of calling theattention of mobile network operators. The expert team wasalso able to develop an app with commendable UI/UX. Theclient appreciates their flexibility in terms.\u201D",
        name: "Othman CHARAI",
        post: "Senior Developer",
        image: "./../../public/images/resource/author-1.jpg"
      },
      {
        text: "\u201CI To helped the client achieve their goal of calling theattention of mobile network operators. The expert team wasalso able to develop an app with commendable UI/UX. Theclient appreciates their flexibility in terms.\u201D",
        name: "Othman CHARAI",
        post: "Senior Developer",
        image: "./../../public/images/resource/author-1.jpg"
      },
      {
        text: "\u201CI To helped the client achieve their goal of calling theattention of mobile network operators. The expert team wasalso able to develop an app with commendable UI/UX. Theclient appreciates their flexibility in terms.\u201D",
        name: "Othman CHARAI",
        post: "Senior Developer",
        image: "./../../public/images/resource/author-1.jpg"
      }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0$1;
      const _component_Swiper = Swiper;
      const _component_SwiperSlide = SwiperSlide;
      _push(`<section${ssrRenderAttrs(mergeProps({
        class: "testimonial-section",
        style: { "background-image": "url(./../../public/images/background/5.jpg)" }
      }, _attrs))}><div class="pattern-layer-one" style="${ssrRenderStyle({ "background-image": "url(./../../public/images/background/pattern-25.png)" })}"></div><div class="auto-container"><div class="row clearfix"><div class="title-column col-lg-5 col-md-12 col-sm-12"><div class="inner-column wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms"><div class="sec-title_two"><div class="sec-title_two-title">Testimonials ~</div><h2 class="sec-title_two-heading"> Here&#39;s what our <br><span>customers</span> have said. </h2><div class="sec-title_two-text"> Simplified IT is designed to help make sure you and your data is protected and your computer runs it&#39;s best. The network Access provides is valuable. </div></div><div class="button-box">`);
      _push(ssrRenderComponent(_component_nuxt_link, {
        class: "btn-style-three theme-btn btn-item",
        to: "/contact"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="btn-wrap"${_scopeId}><span class="text-one"${_scopeId}>View More <i class="fa-solid fa-arrow-right fa-fw"${_scopeId}></i></span><span class="text-two"${_scopeId}>View More <i class="fa-solid fa-arrow-right fa-fw"${_scopeId}></i></span></div>`);
          } else {
            return [
              createVNode("div", { class: "btn-wrap" }, [
                createVNode("span", { class: "text-one" }, [
                  createTextVNode("View More "),
                  createVNode("i", { class: "fa-solid fa-arrow-right fa-fw" })
                ]),
                createVNode("span", { class: "text-two" }, [
                  createTextVNode("View More "),
                  createVNode("i", { class: "fa-solid fa-arrow-right fa-fw" })
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div><div class="carousel-column col-lg-7 col-md-12 col-sm-12"><div class="inner-column" style="${ssrRenderStyle({ "background-image": "url(./../../public/images/background/pattern-26.png)" })}"><div class="authors-outer"><div class="author-one"><img${ssrRenderAttr("src", _imports_0)} alt=""></div><div class="author-two"><img${ssrRenderAttr("src", _imports_1)} alt=""></div><div class="author-three"><img${ssrRenderAttr("src", _imports_2)} alt=""></div><div class="author-four"><img${ssrRenderAttr("src", _imports_3)} alt=""></div></div><div class="single-item-carousel owl-carousel owl-theme">`);
      _push(ssrRenderComponent(_component_Swiper, {
        modules: ["SwiperAutoplay" in _ctx ? _ctx.SwiperAutoplay : unref(Autoplay), "SwiperEffectCreative" in _ctx ? _ctx.SwiperEffectCreative : unref(EffectCreative)],
        "slides-per-view": 1,
        loop: true,
        autoplay: {
          delay: 8e3,
          disableOnInteraction: true
        }
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<!--[-->`);
            ssrRenderList(reviews, (slider) => {
              _push2(ssrRenderComponent(_component_SwiperSlide, {
                class: "slide",
                key: _ctx.slide
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<div class="testimonial-block"${_scopeId2}><div class="inner-box"${_scopeId2}><div class="rating"${_scopeId2}><span class="fa fa-star"${_scopeId2}></span><span class="fa fa-star"${_scopeId2}></span><span class="fa fa-star"${_scopeId2}></span><span class="fa fa-star"${_scopeId2}></span><span class="fa fa-star"${_scopeId2}></span></div><div class="text"${_scopeId2}>${ssrInterpolate(slider.text)}</div></div><div class="author-box"${_scopeId2}><div class="box-inner"${_scopeId2}><span class="author-image"${_scopeId2}><img${ssrRenderAttr("src", slider.image)} alt=""${_scopeId2}></span><h5${_scopeId2}>${ssrInterpolate(slider.name)}</h5><div class="designation"${_scopeId2}>${ssrInterpolate(slider.role)}</div></div></div></div>`);
                  } else {
                    return [
                      createVNode("div", { class: "testimonial-block" }, [
                        createVNode("div", { class: "inner-box" }, [
                          createVNode("div", { class: "rating" }, [
                            createVNode("span", { class: "fa fa-star" }),
                            createVNode("span", { class: "fa fa-star" }),
                            createVNode("span", { class: "fa fa-star" }),
                            createVNode("span", { class: "fa fa-star" }),
                            createVNode("span", { class: "fa fa-star" })
                          ]),
                          createVNode("div", { class: "text" }, toDisplayString(slider.text), 1)
                        ]),
                        createVNode("div", { class: "author-box" }, [
                          createVNode("div", { class: "box-inner" }, [
                            createVNode("span", { class: "author-image" }, [
                              createVNode("img", {
                                src: slider.image,
                                alt: ""
                              }, null, 8, ["src"])
                            ]),
                            createVNode("h5", null, toDisplayString(slider.name), 1),
                            createVNode("div", { class: "designation" }, toDisplayString(slider.role), 1)
                          ])
                        ])
                      ])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            });
            _push2(`<!--]-->`);
          } else {
            return [
              (openBlock(), createBlock(Fragment, null, renderList(reviews, (slider) => {
                return createVNode(_component_SwiperSlide, {
                  class: "slide",
                  key: _ctx.slide
                }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "testimonial-block" }, [
                      createVNode("div", { class: "inner-box" }, [
                        createVNode("div", { class: "rating" }, [
                          createVNode("span", { class: "fa fa-star" }),
                          createVNode("span", { class: "fa fa-star" }),
                          createVNode("span", { class: "fa fa-star" }),
                          createVNode("span", { class: "fa fa-star" }),
                          createVNode("span", { class: "fa fa-star" })
                        ]),
                        createVNode("div", { class: "text" }, toDisplayString(slider.text), 1)
                      ]),
                      createVNode("div", { class: "author-box" }, [
                        createVNode("div", { class: "box-inner" }, [
                          createVNode("span", { class: "author-image" }, [
                            createVNode("img", {
                              src: slider.image,
                              alt: ""
                            }, null, 8, ["src"])
                          ]),
                          createVNode("h5", null, toDisplayString(slider.name), 1),
                          createVNode("div", { class: "designation" }, toDisplayString(slider.role), 1)
                        ])
                      ])
                    ])
                  ]),
                  _: 2
                }, 1024);
              }), 64))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></div></div></section>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home/Review.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_6 = _sfc_main$1;
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_LandingHeader = __nuxt_component_0;
  const _component_HomeSlider = __nuxt_component_1;
  const _component_HomeFeatures = __nuxt_component_2;
  const _component_HomeAbout = __nuxt_component_3;
  const _component_HomeService = __nuxt_component_4;
  const _component_HomeIndestry = __nuxt_component_5;
  const _component_HomeReview = __nuxt_component_6;
  const _component_LandingFooter = __nuxt_component_5$1;
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_LandingHeader, null, null, _parent));
  _push(ssrRenderComponent(_component_HomeSlider, null, null, _parent));
  _push(ssrRenderComponent(_component_HomeFeatures, null, null, _parent));
  _push(ssrRenderComponent(_component_HomeAbout, null, null, _parent));
  _push(ssrRenderComponent(_component_HomeService, null, null, _parent));
  _push(ssrRenderComponent(_component_HomeIndestry, null, null, _parent));
  _push(ssrRenderComponent(_component_HomeReview, null, null, _parent));
  _push(ssrRenderComponent(_component_LandingFooter, null, null, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/home/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { index as default };
//# sourceMappingURL=index-3c132d54.mjs.map
